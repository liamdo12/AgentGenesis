/* Agent Genesis — root app, router, tweaks */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "primary": "#0a8a3f",
  "hierarchyStyle": "nested",
  "density": "regular",
  "chatStyle": "bubbles"
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [screen, setScreen] = React.useState("login");
  const [pending, setPending] = React.useState([]);
  const [extractedIds, setExtractedIds] = React.useState(() => new Set(["mtg-1042"]));
  const [activeMeeting, setActiveMeeting] = React.useState(null);
  const [homeTab, setHomeTab] = React.useState("meetings");
  const [exportItems, setExportItems] = React.useState(null);

  // apply theme + primary
  React.useEffect(() => {
    const root = document.getElementById("agroot");
    if (root) { root.dataset.theme = t.theme; root.style.setProperty("--primary", t.primary); }
  }, [t.theme, t.primary]);

  const go = (s) => setScreen(s);

  return (
    <div id="agroot" data-theme={t.theme} style={{ "--primary": t.primary }}>
      {screen === "login" && <LoginScreen onSignIn={() => go("home")} />}
      {screen === "home" && (
        <HomeScreen extractedIds={extractedIds} activeTab={homeTab} onTab={setHomeTab}
          onSignOut={() => go("login")}
          onGenerate={(m) => { setPending(m); go("extracting"); }}
          onOpenBacklog={(m) => { setActiveMeeting(m); go("workspace"); }} />
      )}
      {screen === "extracting" && (
        <ExtractionScreen meetings={pending} onDone={() => {
          setExtractedIds((prev) => { const n = new Set(prev); pending.forEach((m) => n.add(m.id)); return n; });
          setActiveMeeting(pending[0] || null);
          go("workspace");
        }} />
      )}
      {screen === "workspace" && (
        <WorkspaceScreen meetings={activeMeeting ? [activeMeeting] : pending} onSignOut={() => go("login")} tweaks={t}
          onBack={() => { setHomeTab("stories"); go("home"); }}
          onExport={(items) => setExportItems(items)} />
      )}

      {exportItems && <ExportFlow items={exportItems} onClose={() => setExportItems(null)} />}

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={t.theme} options={["light", "dark"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Primary" value={t.primary} options={["#0a8a3f", "#0e9b8a", "#2f6df0", "#c1456b", "#3a3f45"]} onChange={(v) => setTweak("primary", v)} />
        <TweakSection label="Hierarchy view" />
        <TweakRadio label="Layout" value={t.hierarchyStyle} options={["nested", "board"]} onChange={(v) => setTweak("hierarchyStyle", v)} />
        <TweakRadio label="Density" value={t.density} options={["compact", "regular", "comfy"]} onChange={(v) => setTweak("density", v)} />
        <TweakSection label="AI chat" />
        <TweakRadio label="Message style" value={t.chatStyle} options={["bubbles", "blocks"]} onChange={(v) => setTweak("chatStyle", v)} />
        <TweakSection label="Jump to screen" />
        <div className="tw-jump">
          {[["login","Login"],["home","Home"],["extracting","Extraction"],["workspace","Workspace"]].map(([k,l]) => (
            <button key={k} className={`tw-jumpbtn ${screen===k?"is-on":""}`} onClick={() => go(k)}>{l}</button>
          ))}
        </div>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
