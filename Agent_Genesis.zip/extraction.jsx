/* Agent Genesis — AI extraction / processing state */
function ExtractionScreen({ meetings, onDone }) {
  const transcriptProvided = meetings.some((m) => m.transcriptProvided);
  const steps = [
    { id: 0, label: "Loading recordings & transcripts", sub: meetings.map((m) => m.title).join(", "), icon: <Icons.Video size={16} /> },
    transcriptProvided
      ? { id: 1, label: "Reading your uploaded transcript", sub: "Using the transcript you provided", icon: <Icons.Transcript size={16} /> }
      : { id: 1, label: "Transcribing & diarizing speakers", sub: "Aligning who said what to the timeline", icon: <Icons.Mic size={16} /> },
    { id: 2, label: "Sampling key video frames", sub: "Whiteboards, screen-shares, and slides", icon: <Icons.Sparkle size={16} /> },
    { id: 3, label: "Identifying requirements & intent", sub: "Clustering decisions, asks, and constraints", icon: <Icons.Layers size={16} /> },
    { id: 4, label: "Structuring epics → features → stories → tasks", sub: "Drafting acceptance criteria and estimates", icon: <Icons.Layers size={16} /> },
  ];
  const [active, setActive] = React.useState(0);
  const [done, setDone] = React.useState(-1);

  React.useEffect(() => {
    let i = 0;
    const tick = () => {
      setDone(i);
      i += 1;
      if (i < steps.length) {
        setActive(i);
        timer = setTimeout(tick, 1150);
      } else {
        timer = setTimeout(onDone, 1000);
      }
    };
    let timer = setTimeout(tick, 1150);
    setActive(0);
    return () => clearTimeout(timer);
  }, []);

  const pct = Math.min(100, Math.round(((done + 1) / steps.length) * 100));

  return (
    <div className="screen extraction">
      <div className="extraction__stage">
        <div className="extraction__halo">
          <div className="extraction__orb"><AgentMark size={46} /></div>
          <div className="extraction__ring" />
          <div className="extraction__ring extraction__ring--2" />
        </div>

        <h1>Reading your meeting{meetings.length > 1 ? "s" : ""}…</h1>
        <p className="extraction__sub">Agent Genesis is watching the recording and reading the transcript to draft your backlog.</p>

        <div className="extraction__bar"><div className="extraction__barfill" style={{ width: pct + "%" }} /></div>
        <div className="extraction__pct">{pct}%</div>

        <div className="extraction__steps">
          {steps.map((s) => {
            const state = done >= s.id ? "done" : active === s.id ? "active" : "idle";
            return (
              <div key={s.id} className={`xstep is-${state}`}>
                <div className="xstep__icon">
                  {state === "done" ? <Icons.Check size={15} sw={2.6} /> : state === "active" ? <Spinner size={15} /> : s.icon}
                </div>
                <div className="xstep__txt">
                  <div className="xstep__label">{s.label}</div>
                  <div className="xstep__sub">{s.sub}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="extraction__frames">
        {["violet", "blue", "amber", "green"].map((t, i) => (
          <div key={t} className="extraction__framewrap" style={{ animationDelay: i * 0.4 + "s" }}>
            <FrameThumb tint={t} w={150} h={88} label={`frame ${(i + 1) * 7}:0${i}`} />
          </div>
        ))}
      </div>
    </div>
  );
}
window.ExtractionScreen = ExtractionScreen;
