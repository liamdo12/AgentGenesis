/* Agent Genesis — shared UI atoms. Exposed to window. */

const initials = (name) =>
  name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();

const Avatar = ({ name, size = 26 }) => {
  const color = (window.AG.PEOPLE[name]) || "#6b7280";
  return (
    <div className="ag-avatar" title={name} style={{
      width: size, height: size, background: color, fontSize: size * 0.4,
    }}>{initials(name)}</div>
  );
};

const AvatarStack = ({ names, max = 4, size = 26 }) => {
  const shown = names.slice(0, max);
  const extra = names.length - shown.length;
  return (
    <div className="ag-avstack">
      {shown.map((n, i) => (
        <div key={n} style={{ marginLeft: i ? -8 : 0, zIndex: max - i }}>
          <Avatar name={n} size={size} />
        </div>
      ))}
      {extra > 0 && (
        <div className="ag-avatar ag-avatar--more" style={{ width: size, height: size, marginLeft: -8, fontSize: size * 0.34 }}>+{extra}</div>
      )}
    </div>
  );
};

const TypePill = ({ type, withLabel = true, size = "md" }) => {
  const t = window.AG.TYPE[type];
  return (
    <span className={`ag-typepill ag-typepill--${size}`} style={{ color: t.color, background: t.soft }}>
      <span className="ag-typepill__dot" style={{ background: t.color }} />
      {withLabel && t.label}
    </span>
  );
};

const TypeGlyph = ({ type, size = 22 }) => {
  const t = window.AG.TYPE[type];
  return (
    <span className="ag-typeglyph" style={{ width: size, height: size, color: t.color, background: t.soft, fontSize: size * 0.5 }}>
      {t.letter}
    </span>
  );
};

const PriorityTag = ({ priority }) => {
  if (!priority) return null;
  const p = window.AG.PRIORITY[priority];
  return <span className="ag-prio" style={{ color: p.color, background: p.soft }}>{priority}</span>;
};

const Points = ({ value }) => {
  if (value == null) return null;
  return <span className="ag-points" title={value + " story points"}>{value}<span className="ag-points__u">pt</span></span>;
};

// Approve checkbox / state control
const ApproveBox = ({ status, onClick }) => {
  const approved = status === "approved";
  return (
    <button className={`ag-approve ${approved ? "is-approved" : ""}`} onClick={onClick}
            style={approved ? { background: "#15915b", borderColor: "#15915b", color: "#fff" } : undefined}
            title={approved ? "Approved — click to unapprove" : "Approve"}>
      {approved ? <Icons.Check size={13} sw={2.6} /> : null}
    </button>
  );
};

const StatusChip = ({ status }) => {
  const map = {
    approved: { label: "Approved", cls: "is-approved" },
    pending: { label: "Needs review", cls: "is-pending" },
    suggested: { label: "AI suggested", cls: "is-suggested" },
  };
  const s = map[status] || map.pending;
  return <span className={`ag-status ${s.cls}`}>{s.label}</span>;
};

// Placeholder "video frame" thumbnail with timestamp + play affordance
const FrameThumb = ({ ts, tint = "violet", w = 132, h = 76, label }) => {
  const tints = {
    violet: ["#312e6e", "#5b4bb3", "#8b7fd6"],
    blue: ["#163a5c", "#1d6fb0", "#5aa6dd"],
    amber: ["#5a3a14", "#b06a1d", "#e0a256"],
    green: ["#163f30", "#1f7a55", "#5cb58a"],
    rose: ["#5a1c38", "#b03568", "#e07ba0"],
  };
  const c = tints[tint] || tints.violet;
  return (
    <div className="ag-frame" style={{ width: w, height: h, background: `linear-gradient(135deg, ${c[0]}, ${c[1]} 55%, ${c[2]})` }}>
      <div className="ag-frame__grain" />
      <div className="ag-frame__play"><Icons.Play size={14} /></div>
      {ts && <span className="ag-frame__ts">{ts}</span>}
      {label && <span className="ag-frame__label">{label}</span>}
    </div>
  );
};

// Source provenance chip (timestamp + optional quote on hover)
const SourceChip = ({ source, onJump }) => {
  if (!source) return null;
  return (
    <button className="ag-source" onClick={onJump} title={source.quote ? "“" + source.quote + "”" : "Jump to source"}>
      <Icons.Play size={11} />
      <span className="ag-source__ts">{source.ts}</span>
      <span className="ag-source__sep">·</span>
      <span className="ag-source__txt">source</span>
    </button>
  );
};

const Btn = ({ children, variant = "default", size = "md", icon, iconRight, onClick, disabled, style, full }) => (
  <button className={`ag-btn ag-btn--${variant} ag-btn--${size} ${full ? "ag-btn--full" : ""}`} onClick={onClick} disabled={disabled} style={style}>
    {icon}{children && <span>{children}</span>}{iconRight}
  </button>
);

const Segmented = ({ options, value, onChange }) => (
  <div className="ag-seg">
    {options.map((o) => (
      <button key={o.value} className={`ag-seg__btn ${value === o.value ? "is-on" : ""}`} onClick={() => onChange(o.value)}>
        {o.icon}{o.label && <span>{o.label}</span>}
      </button>
    ))}
  </div>
);

const Spinner = ({ size = 16 }) => (
  <span className="ag-spinner" style={{ width: size, height: size }} />
);

Object.assign(window, {
  initials, Avatar, AvatarStack, TypePill, TypeGlyph, PriorityTag, Points,
  ApproveBox, StatusChip, FrameThumb, SourceChip, Btn, Segmented, Spinner,
});
