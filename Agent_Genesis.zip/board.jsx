/* Agent Genesis — Board view: Miller-column navigator (Epic → Feature → Story → Task)
   Each hierarchy level is its own vertical lane; selecting an item reveals its
   children in the next lane. The last selected item's full context shows in a
   detail lane on the right. */

function sumPoints(node) {
  let v = node.points || 0;
  (node.children || []).forEach((c) => { v += sumPoints(c); });
  return v;
}

const COL_META = {
  epic: { label: "Epics", next: "feature" },
  feature: { label: "Features", next: "story" },
  story: { label: "User Stories", next: "task" },
  task: { label: "Tasks", next: null },
};

function BoardView({ data, focusedId, onFocus, onApprove, onJump, onOpenDetail, path, onPick }) {
  // Build the chain of lanes from the current selection path.
  const lanes = [];
  let level = data;
  let type = "epic";
  for (let depth = 0; ; depth++) {
    lanes.push({ type, items: level, selectedId: path[depth] || null });
    const sel = level.find((n) => n.id === path[depth]);
    if (!sel || !sel.children || sel.children.length === 0) break;
    level = sel.children;
    type = COL_META[type].next;
    if (!type) break;
  }

  const leaf = (() => {
    let node = null, lvl = data;
    for (const id of path) {
      const f = lvl.find((n) => n.id === id);
      if (!f) break;
      node = f; lvl = f.children || [];
    }
    return node;
  })();

  // Keep the deepest lane in view as the selection changes.
  const colsRef = React.useRef(null);
  React.useEffect(() => {
    const el = colsRef.current;
    if (el) el.scrollTo({ left: el.scrollWidth, behavior: "smooth" });
  }, [path.join("/")]);

  return (
    <div className="mboard">
      <div className="mboard__cols" ref={colsRef}>
        {lanes.map((lane, i) => (
          <BoardColumn key={i} lane={lane} depth={i}
                       onApprove={onApprove}
                       onPick={(node) => onPick(i, node)} />
        ))}
      </div>
      <BoardDetailPane node={leaf} onApprove={onApprove} onJump={onJump} />
    </div>
  );
}

function BoardColumn({ lane, depth, onApprove, onPick }) {
  const { type, items, selectedId } = lane;
  const meta = COL_META[type];
  const st = window.countStatus(items);
  return (
    <div className={`mcol mcol--${type}`}>
      <div className="mcol__head">
        <div className="mcol__headleft">
          <TypePill type={type} size="sm" />
          <span className="mcol__count">{items.length}</span>
        </div>
        <span className="mcol__approved">{st.approved}/{st.total}</span>
      </div>
      <div className="mcol__list">
        {items.map((node) => {
          const kids = node.children || [];
          const sub = kids.length ? window.countStatus(kids) : null;
          return (
            <button key={node.id}
                    className={`mitem ${selectedId === node.id ? "is-selected" : ""} ${node.status === "approved" ? "is-approved" : ""} ${node.status === "suggested" ? "is-suggested" : ""}`}
                    onClick={() => onPick(node)}>
              <span className="mitem__check"
                    onClick={(e) => { e.stopPropagation(); onApprove(node.id); }}
                    title={node.status === "approved" ? "Approved — click to unapprove" : "Mark approved"}>
                {node.status === "approved" ? <Icons.Check size={11} sw={3} /> : <span className="mitem__dot" />}
              </span>
              <span className="mitem__body">
                <span className="mitem__title">{node.title}</span>
                <span className="mitem__meta">
                  <span className="mitem__id">{node.id}</span>
                  {node.priority && <PriorityDot priority={node.priority} />}
                  {node.points != null && <span className="mitem__pts">{node.points}</span>}
                  {sub && <span className="mitem__roll">{sub.approved}/{sub.total}</span>}
                </span>
              </span>
              {kids.length > 0 && <Icons.Chevron size={15} style={{ flex: "none", color: "var(--faint)" }} />}
            </button>
          );
        })}
        {items.length === 0 && <div className="mcol__empty">Nothing here yet</div>}
      </div>
    </div>
  );
}

function PriorityDot({ priority }) {
  const p = (window.AG.PRIORITY || {})[priority] || {};
  return <span className="mitem__pdot" style={{ background: p.color }} title={priority} />;
}

function BoardDetailPane({ node, onApprove, onJump }) {
  if (!node) {
    return (
      <div className="mdetail mdetail--empty">
        <Icons.Layers size={26} />
        <p>Select an item to see its full context</p>
      </div>
    );
  }
  const approved = node.status === "approved";
  return (
    <div className="mdetail">
      <div className="mdetail__head">
        <div className="mdetail__headrow">
          <TypeGlyph type={node.type} size={28} />
          <div className="mdetail__headtxt">
            <div className="mdetail__crumbs">
              <TypePill type={node.type} size="sm" />
              <span className="mdetail__id">{node.id}</span>
            </div>
          </div>
        </div>
        <h2 className="mdetail__title">{node.title}</h2>
        <div className="mdetail__tags">
          {node.priority && <PriorityTag priority={node.priority} />}
          {node.points != null && <Points value={node.points} />}
        </div>
      </div>
      <div className="mdetail__body">
        <NodeDetail node={node} onJump={onJump} />
      </div>
      <div className="mdetail__foot">
        <span className="mdetail__footstatus">
          {approved ? <React.Fragment><Icons.CheckCircle size={15} /> Approved</React.Fragment> : "Pending review"}
        </span>
        <Btn variant={approved ? "default" : "primary"} size="sm"
             icon={approved ? <Icons.Close size={15} /> : <Icons.Check size={15} sw={2.4} />}
             onClick={() => onApprove(node.id)}>
          {approved ? "Unapprove" : "Approve item"}
        </Btn>
      </div>
    </div>
  );
}

window.BoardView = BoardView;
