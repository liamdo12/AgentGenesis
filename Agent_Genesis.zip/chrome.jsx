/* Agent Genesis — shared app chrome (top header) */
function AppHeader({ crumb, onSignOut, right }) {
  const [menu, setMenu] = React.useState(false);
  return (
    <header className="appheader">
      <div className="appheader__left">
        <div className="appheader__brand">
          <AgentMark size={22} />
          <span>Agent Genesis</span>
        </div>
        {crumb && <><span className="appheader__div">/</span><span className="appheader__crumb">{crumb}</span></>}
      </div>
      <div className="appheader__right">
        {right}
        <div className="appheader__user">
          <button className="appheader__userbtn" onClick={() => setMenu((v) => !v)}>
            <Avatar name="Priya Raman" size={30} />
            <div className="appheader__userinfo">
              <span className="appheader__name">Priya Raman</span>
              <span className="appheader__org">Contoso</span>
            </div>
            <Icons.ChevronDown size={15} style={{ color: "var(--faint)" }} />
          </button>
          {menu && (
            <>
              <div className="appheader__scrim" onClick={() => setMenu(false)} />
              <div className="appheader__menu">
                <div className="appheader__menuhead">
                  <Avatar name="Priya Raman" size={36} />
                  <div>
                    <div className="appheader__name">Priya Raman</div>
                    <div className="appheader__mail">priya.raman@contoso.com</div>
                  </div>
                </div>
                <button className="appheader__menuitem"><Icons.Shield size={16} /> Connected accounts</button>
                <button className="appheader__menuitem" onClick={onSignOut}><Icons.Logout size={16} /> Sign out</button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
window.AppHeader = AppHeader;
