/* Agent Genesis — Workspace: hierarchy + chat + toolbar */

// ---- tree helpers (immutable) ----
function annotate(nodes, parentId = null) {
  return nodes.map((n) => ({ ...n, _parentId: parentId, children: n.children ? annotate(n.children, n.id) : [] }));
}
function findNode(nodes, id) {
  for (const n of nodes) {
    if (n.id === id) return n;
    if (n.children) { const f = findNode(n.children, id); if (f) return f; }
  }
  return null;
}
function mapNode(nodes, id, fn) {
  return nodes.map((n) => {
    if (n.id === id) return fn(n);
    if (n.children && n.children.length) return { ...n, children: mapNode(n.children, id, fn) };
    return n;
  });
}
function setStatusDeep(node, status) {
  return { ...node, status, children: (node.children || []).map((c) => setStatusDeep(c, status)) };
}
function allIds(nodes, acc = []) {
  for (const n of nodes) { acc.push(n.id); if (n.children) allIds(n.children, acc); }
  return acc;
}
let _idc = 100;
const newId = (p) => `${p}-${++_idc}`;

function WorkspaceScreen({ meetings, onSignOut, onExport, tweaks }) {
  const meeting = (meetings && meetings[0]) || window.AG.meetings[0];
  const [data, setData] = React.useState(() => annotate(window.AG.tree));
  const [expanded, setExpanded] = React.useState(() => new Set(["EPIC-1", "FEAT-1", "EPIC-2"]));
  const [focusedId, setFocusedId] = React.useState("US-1");
  const [recentId, setRecentId] = React.useState(null);
  const [preview, setPreview] = React.useState(null);
  const [boardPath, setBoardPath] = React.useState(["EPIC-1", "FEAT-1", "US-1"]);
  const [filterUnapproved, setFilterUnapproved] = React.useState(false);
  const [chatOpen, setChatOpen] = React.useState(true);

  const isBoard = tweaks.hierarchyStyle === "board";
  // Pick at lane `depth`: keep ancestors, set this node, drop deeper selections.
  const boardPick = (depth, node) => {
    setBoardPath((p) => [...p.slice(0, depth), node.id]);
    setFocusedId(node.id);
  };

  const focusedNode = focusedId ? findNode(data, focusedId) : null;
  const stats = window.countStatus(data);

  const toggle = (id) => setExpanded((p) => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const expandAll = () => setExpanded(new Set(allIds(data)));
  const collapseAll = () => setExpanded(new Set());

  const approve = (id) => {
    setData((d) => mapNode(d, id, (n) => setStatusDeep(n, n.status === "approved" ? "pending" : "approved")));
  };

  const flash = (id) => { setRecentId(id); setTimeout(() => setRecentId((r) => (r === id ? null : r)), 1600); };

  const applyAction = (action) => {
    if (!action) return false;
    if (action.kind === "addAC") {
      setData((d) => mapNode(d, action.nodeId, (n) => ({ ...n, ac: [...(n.ac || []), ...action.items], status: "pending" })));
      setExpanded((p) => new Set(p).add(action.nodeId));
      setFocusedId(action.nodeId); flash(action.nodeId);
      return true;
    }
    if (action.kind === "setField") {
      setData((d) => mapNode(d, action.nodeId, (n) => ({ ...n, [action.field]: action.value })));
      flash(action.nodeId);
      return true;
    }
    if (action.kind === "addTask") {
      const id = newId("TASK");
      const task = { id, type: "task", status: "suggested", source: focusedNode ? focusedNode.source : null, children: [], _parentId: action.parentId, ...action.task };
      setData((d) => mapNode(d, action.parentId, (n) => ({ ...n, children: [...(n.children || []), task] })));
      setExpanded((p) => new Set(p).add(action.parentId));
      setFocusedId(id); flash(id);
      return true;
    }
    if (action.kind === "addStory") {
      const parentId = action.parentId || (focusedNode && focusedNode._parentId);
      if (!parentId) return false;
      const id = newId("US");
      const story = { id, type: "story", status: "suggested", source: focusedNode ? focusedNode.source : null, children: [], _parentId: parentId, ...action.story };
      setData((d) => mapNode(d, parentId, (n) => ({ ...n, children: [...(n.children || []), story] })));
      setExpanded((p) => new Set(p).add(parentId));
      setFocusedId(id); flash(id);
      return true;
    }
    return false;
  };

  return (
    <div className="screen workspace">
      <AppHeader crumb={meeting.title} onSignOut={onSignOut}
        right={<div className="ws__headstats"><Icons.CheckCircle size={15} /> {stats.approved}/{stats.total} approved</div>} />

      <div className="ws__toolbar">
        <div className="ws__source">
          <FrameThumb ts={meeting.duration} tint={meeting.tint} w={56} h={34} />
          <div className="ws__sourceinfo">
            <div className="ws__sourcetitle"><TeamsLogo size={14} /> {meeting.title}</div>
            <div className="ws__sourcemeta">{meeting.date} · {stats.total} work items · {pointsTotal(data)} points</div>
          </div>
        </div>
        <div className="ws__toolspacer" />
        <button className={`ag-chiptoggle ${filterUnapproved ? "is-on" : ""}`} onClick={() => setFilterUnapproved((v) => !v)}>
          <Icons.Filter size={14} /> Needs review
        </button>
        {!isBoard && (
          <React.Fragment>
            <button className="ag-iconbtn" title="Expand all" onClick={expandAll}><Icons.Expand size={16} /></button>
            <button className="ag-iconbtn" title="Collapse all" onClick={collapseAll}><Icons.Collapse size={16} /></button>
          </React.Fragment>
        )}
        <div className="ws__divider" />
        <button className={`ag-iconbtn ${chatOpen ? "is-on" : ""}`} title={chatOpen ? "Hide AI chat" : "Show AI chat"} onClick={() => setChatOpen((v) => !v)}>
          <Icons.Chat size={16} />
        </button>
        <Btn variant="primary" icon={<AzureDevOpsLogo size={16} />} disabled={stats.approved === 0}
             onClick={() => onExport(approvedTree(data))}>
          Export to Azure DevOps {stats.approved > 0 && <span className="ws__expcount">{stats.approved}</span>}
        </Btn>
      </div>

      <div className={`ws__main ${chatOpen ? "" : "ws__main--nochat"}`}>
        <div className={`ws__center ${isBoard ? "ws__center--board" : ""}`}>
          <div className="ws__progress">
            <div className="ws__progressbar"><div className="ws__progressfill" style={{ width: (stats.approved / stats.total * 100) + "%" }} /></div>
            <span className="ws__progresslabel">{stats.approved} of {stats.total} items approved</span>
            <span className="ws__viewtag">{isBoard ? "Board view" : "Nested view"}</span>
          </div>
          {isBoard ? (
            <BoardView data={filterUnapproved ? filterTree(data) : data}
                       focusedId={focusedId} onApprove={approve} onJump={setPreview}
                       path={boardPath} onPick={boardPick} />
          ) : (
            <TreeView data={filterUnapproved ? filterTree(data) : data} expanded={expanded} onToggle={toggle}
                      focusedId={focusedId} onFocus={setFocusedId} onApprove={approve} onJump={setPreview}
                      hierarchyStyle={tweaks.hierarchyStyle} density={tweaks.density} recentId={recentId} />
          )}
        </div>
        {chatOpen ? (
          <ChatDock focusedNode={focusedNode} onApplyAction={applyAction} chatStyle={tweaks.chatStyle} onCollapse={() => setChatOpen(false)} />
        ) : (
          <button className="chatrail" title="Open AI chat" onClick={() => setChatOpen(true)}>
            <span className="chatrail__icon"><AgentMark size={18} /></span>
            <span className="chatrail__label">AI Chat</span>
            <Icons.Chevron size={15} style={{ transform: "rotate(180deg)", color: "var(--faint)" }} />
          </button>
        )}
      </div>

      {preview && <SourcePreview node={preview} meeting={meeting} onClose={() => setPreview(null)} />}
    </div>
  );
}

function pointsTotal(nodes, acc = { v: 0 }) {
  for (const n of nodes) { if (n.points) acc.v += n.points; if (n.children) pointsTotal(n.children, acc); }
  return acc.v;
}
function filterTree(nodes) {
  return nodes.map((n) => ({ ...n, children: n.children ? filterTree(n.children) : [] }))
    .filter((n) => n.status !== "approved" || (n.children && n.children.some((c) => c.status !== "approved")) || hasUnapproved(n));
}
function hasUnapproved(n) {
  if (n.status !== "approved") return true;
  return (n.children || []).some(hasUnapproved);
}
function approvedTree(nodes) {
  return nodes.map((n) => ({ ...n, children: n.children ? approvedTree(n.children) : [] }))
    .filter((n) => n.status === "approved" || (n.children && n.children.length));
}

function SourcePreview({ node, meeting, onClose }) {
  return (
    <div className="modal" onClick={onClose}>
      <div className="srcprev" onClick={(e) => e.stopPropagation()}>
        <button className="modal__close" onClick={onClose}><Icons.Close size={18} /></button>
        <div className="srcprev__video">
          <FrameThumb ts={node.source && node.source.ts} tint={(node.source && node.source.tint) || "violet"} w={520} h={292} />
          <div className="srcprev__scrub"><div className="srcprev__scrubfill" /></div>
        </div>
        <div className="srcprev__side">
          <div className="srcprev__metahead"><TeamsLogo size={15} /> {meeting.title}</div>
          <div className="srcprev__ts"><Icons.Clock size={14} /> Source moment · {node.source && node.source.ts}</div>
          <div className="srcprev__forwhat"><TypePill type={node.type} size="sm" /> <span>{node.title}</span></div>
          {node.source && node.source.quote ? (
            <blockquote className="srcprev__quote">“{node.source.quote}”</blockquote>
          ) : <p className="srcprev__noquote">This item was inferred from the surrounding discussion and on-screen content around {node.source && node.source.ts}.</p>}
          <div className="srcprev__transcript">
            <div className="srcprev__tlabel">Transcript</div>
            <div className="srcprev__line"><Avatar name={meeting.organizer} size={22} /><span><b>{meeting.organizer}</b> {node.source && node.source.quote ? node.source.quote : "…and that's the behavior we'd want there."}</span></div>
            <div className="srcprev__line"><Avatar name="Devon Clarke" size={22} /><span><b>Devon Clarke</b> Agreed — let's make sure that's captured as a requirement.</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.WorkspaceScreen = WorkspaceScreen;
