// Agent Genesis — mock data. Exposed on window.AG.
(function () {
  // ---- Meeting records (Microsoft Teams) ----
  const meetings = [
    {
      id: "mtg-1042",
      title: "Returns Portal — Discovery Workshop",
      date: "Jun 11, 2026",
      time: "10:00 AM",
      duration: "58 min",
      organizer: "Priya Raman",
      attendees: ["Priya Raman", "Devon Clarke", "Mara Ng", "Sam Whitfield", "Lola Fischer"],
      channel: "Retail Platform / Sprint 24",
      hasVideo: true,
      hasTranscript: true,
      transcriptWords: 8420,
      tint: "violet",
      selected: false,
    },
    {
      id: "mtg-1039",
      title: "Mobile Checkout — Stakeholder Review",
      date: "Jun 9, 2026",
      time: "2:30 PM",
      duration: "44 min",
      organizer: "Devon Clarke",
      attendees: ["Devon Clarke", "Priya Raman", "Yusuf Adeyemi"],
      channel: "Retail Platform / Sprint 24",
      hasVideo: true,
      hasTranscript: true,
      transcriptWords: 6110,
      tint: "blue",
      selected: false,
    },
    {
      id: "mtg-1036",
      title: "Loyalty Tier Revamp — Kickoff",
      date: "Jun 5, 2026",
      time: "9:00 AM",
      duration: "1h 12min",
      organizer: "Mara Ng",
      attendees: ["Mara Ng", "Priya Raman", "Devon Clarke", "Aria Patel", "Tom Becker", "Lola Fischer"],
      channel: "Growth / Q3 Planning",
      hasVideo: true,
      hasTranscript: true,
      transcriptWords: 10240,
      tint: "amber",
      selected: false,
    },
    {
      id: "mtg-1031",
      title: "Search Relevance — Eng Sync",
      date: "Jun 3, 2026",
      time: "11:30 AM",
      duration: "31 min",
      organizer: "Yusuf Adeyemi",
      attendees: ["Yusuf Adeyemi", "Sam Whitfield", "Aria Patel"],
      channel: "Search / Sprint 24",
      hasVideo: false,
      hasTranscript: true,
      transcriptWords: 4300,
      tint: "green",
      selected: false,
    },
    {
      id: "mtg-1028",
      title: "Onboarding Funnel — Design Critique",
      date: "May 29, 2026",
      time: "3:00 PM",
      duration: "52 min",
      organizer: "Lola Fischer",
      attendees: ["Lola Fischer", "Mara Ng", "Devon Clarke"],
      channel: "Growth / Q3 Planning",
      hasVideo: true,
      hasTranscript: true,
      transcriptWords: 7650,
      tint: "rose",
      selected: false,
    },
  ];

  // ---- Extracted hierarchy ----
  // Node fields:
  //   id, type, title, desc, priority, points, status, source{ts,quote,tint}, children[]
  // Optional context fields (rendered in the detail panel when an item is focused):
  //   value      — business value / outcome statement (epic, feature)
  //   metrics[]  — measurable success metrics (epic)
  //   scopeIn[]  / scopeOut[] — in / out of scope (epic)
  //   flows[]    — key user flows, ordered (feature)
  //   ac[]       — acceptance criteria (story)
  //   example    — worked example scenario (story)
  //   edge[]     — edge cases & considerations (story)
  //   steps[]    — implementation / reproduction steps, ordered (task)
  //   notes      — technical note (task, feature)
  //   deps[]     — dependencies / blockers (any)
  //   questions[]— open questions to resolve (epic, feature)
  const tree = [
    {
      id: "EPIC-1",
      type: "epic",
      title: "Self-Service Returns Portal",
      desc: "Let customers initiate, track, and complete returns without contacting support, reducing return-related ticket volume.",
      priority: "High",
      status: "pending",
      value: "Cuts return-related support contacts by an estimated 60% and shortens refund turnaround, directly lowering cost-to-serve and lifting post-purchase NPS.",
      metrics: [
        "Return-related support tickets ↓ 60% within two quarters",
        "Median time-to-refund under 3 business days",
        "≥ 70% of returns initiated with no agent involvement",
      ],
      scopeIn: [
        "Customer-initiated returns & exchanges on delivered orders",
        "Prepaid return label generation",
        "Refund processing with agent review above a threshold",
      ],
      scopeOut: [
        "In-store / point-of-sale returns",
        "Cross-border customs handling",
        "Warranty & repair claims",
      ],
      deps: ["Order Management Service (delivery + eligibility data)", "Payments service (refund issuance)"],
      questions: [
        "Do exchanges reuse this flow or branch after item selection?",
        "How are partial returns of multi-item orders handled?",
      ],
      source: { ts: "04:12", quote: "If a shopper could just start the return themselves from their order list, we'd kill most of our support load.", tint: "violet" },
      children: [
        {
          id: "FEAT-1",
          type: "feature",
          title: "Return initiation flow",
          desc: "Entry points and guided steps for a customer to begin a return from order history.",
          priority: "High",
          status: "pending",
          value: "Removes the top friction point — finding where to start — by anchoring returns to the order the customer is already looking at.",
          flows: [
            "Order history → 'Return or exchange' on an eligible order",
            "Return wizard: select items → choose reason → confirm",
            "Confirmation screen with label + tracking",
          ],
          deps: ["Eligibility rules from Order Management", "Return-reason taxonomy (shared with analytics)"],
          questions: ["Should ineligible items be hidden, or shown disabled with a reason?"],
          source: { ts: "06:48", quote: "Start point has to live right next to the order, not buried in a help center.", tint: "violet" },
          children: [
            {
              id: "US-1",
              type: "story",
              title: "Start a return from order history",
              desc: "As a customer, I want to begin a return directly from a past order so that I don't have to search for the right item.",
              priority: "High",
              points: 5,
              status: "pending",
              ac: [
                "A 'Return or exchange' action appears on every eligible delivered order.",
                "Items outside the 30-day window show a disabled state with a reason.",
                "Selecting the action opens the return wizard pre-filled with that order.",
              ],
              example: "Priya's May 20 order (delivered May 24) is opened on Jun 12. She taps 'Return or exchange' and the wizard opens pre-filled: a sneaker pair (19 days post-delivery) is eligible, while a gift-card line item is hidden as non-returnable.",
              edge: [
                "Order delivered exactly 30 days ago — boundary stays eligible until end of day.",
                "Mixed order where some items are past the window and some are eligible.",
                "Order with no recorded delivery date — fall back to ship date + buffer.",
              ],
              deps: ["Eligibility window service", "Analytics event schema"],
              source: { ts: "07:20", quote: "Eligibility window is 30 days from delivery, and we should grey out anything past that with a why.", tint: "violet" },
              children: [
                {
                  id: "TASK-1", type: "task", title: "Add 'Return or exchange' entry point to order card",
                  desc: "Order-history component, eligibility gating, analytics event.",
                  priority: "High", points: 3, status: "pending",
                  steps: [
                    "Add the action button to OrderCard, gated on `order.eligibleForReturn`.",
                    "Wire the disabled state + tooltip reason when outside the window.",
                    "Emit a `return_initiated` analytics event with order and item ids.",
                    "Cover eligible / ineligible states with unit + visual-regression tests.",
                  ],
                  notes: "Button must not shift card layout when hidden — reserve the space or collapse cleanly.",
                  deps: ["Eligibility flag exposed on the order payload"],
                  source: { ts: "08:02", tint: "violet" }, children: [],
                },
                {
                  id: "TASK-2", type: "task", title: "Build return-reason selection step",
                  desc: "Reason taxonomy, single-select with 'other' free text.",
                  priority: "Medium", points: 2, status: "pending",
                  steps: [
                    "Render the reason taxonomy as a single-select list.",
                    "Show an 'Other' free-text field (max 250 chars) when selected.",
                    "Persist the selection to the draft return record.",
                    "Block 'Continue' until a reason is chosen.",
                  ],
                  notes: "The reason taxonomy is shared with Returns Analytics — import the shared enum, don't redefine it.",
                  source: { ts: "09:15", tint: "violet" }, children: [],
                },
              ],
            },
            {
              id: "US-2",
              type: "story",
              title: "Generate a prepaid shipping label",
              desc: "As a customer, I want a prepaid return label so that I can ship the item back without paying upfront.",
              priority: "High",
              points: 8,
              status: "pending",
              ac: [
                "A printable PDF label is generated once a return is confirmed.",
                "The label is also emailed to the customer's account address.",
                "Carrier and cost are selected by the rules engine, not the customer.",
              ],
              example: "After confirming a one-jacket return, the customer sees a 'Download return label (PDF)' button and a copy lands in their inbox. The carrier (regional ground) and $0 customer cost were picked by the rules engine and never surfaced as a choice.",
              edge: [
                "Carrier API timeout — show retry, then fall back to 'email when ready'.",
                "Customer in a region with no supported carrier.",
                "Re-printing a label for the same return must not mint a new tracking number.",
              ],
              deps: ["Carrier rules engine", "Transactional email service"],
              source: { ts: "12:36", quote: "They shouldn't pick the carrier — we decide based on cost and the item's region.", tint: "violet" },
              children: [
                {
                  id: "TASK-3", type: "task", title: "Integrate carrier label API",
                  desc: "Shippo/EasyPost adapter behind a rules engine.",
                  priority: "High", points: 5, status: "pending",
                  steps: [
                    "Build an adapter interface over Shippo / EasyPost.",
                    "Feed the rules engine: item region, weight, and value.",
                    "Cache the generated label + tracking on the return record.",
                    "Handle and surface carrier API errors gracefully.",
                  ],
                  notes: "Use an idempotency key per return so a retry never produces a duplicate label.",
                  deps: ["Carrier account credentials in the secrets vault"],
                  source: { ts: "13:10", tint: "violet" }, children: [],
                },
                {
                  id: "TASK-4", type: "task", title: "Email label to customer",
                  desc: "Transactional email template + attachment.",
                  priority: "Medium", points: 2, status: "pending",
                  steps: [
                    "Create a transactional template with the label PDF attached.",
                    "Trigger it on the return-confirmation event.",
                    "Include the tracking number and drop-off instructions.",
                  ],
                  source: { ts: "14:02", tint: "violet" }, children: [],
                },
              ],
            },
          ],
        },
        {
          id: "FEAT-2",
          type: "feature",
          title: "Refund processing",
          desc: "Backend rules and agent tooling to approve and issue refunds for returned items.",
          priority: "Medium",
          status: "pending",
          value: "Protects margin by keeping low-risk refunds instant while routing high-value ones to human review — balancing speed against fraud control.",
          flows: [
            "Item scanned in at the warehouse → refund eligibility evaluated",
            "≤ threshold: auto-refund to the original tender",
            "> threshold: agent approval queue → approve or deny",
          ],
          deps: ["Payments service", "Warehouse scan-in events"],
          questions: ["Is the $50 threshold global, or configurable per category?"],
          source: { ts: "21:40", quote: "Anything over fifty bucks needs an agent to eyeball it before the money goes back.", tint: "violet" },
          children: [
            {
              id: "US-3",
              type: "story",
              title: "Approve refunds above threshold",
              desc: "As a support agent, I want refunds over $50 to require my approval so that we control fraud and error.",
              priority: "Medium",
              points: 5,
              status: "pending",
              ac: [
                "Refunds ≤ $50 auto-approve on item scan-in.",
                "Refunds > $50 enter an agent approval queue.",
                "Agents see order, reason, and return-condition photos in one view.",
              ],
              example: "A $120 coat is scanned in and, being over $50, lands in the agent queue. The agent sees the order, the reason ('arrived damaged'), and two condition photos on one screen, approves, and the refund posts to the original card.",
              edge: [
                "Refund amount exactly at the $50 threshold — auto-approves.",
                "Condition photos missing — agent can request them before deciding.",
                "Original payment method expired — route to an alternate refund path.",
              ],
              deps: ["Payments refund API", "Condition-photo capture at intake"],
              source: { ts: "22:15", quote: "Give the agent the photos and the reason in one screen so they're not tab-hopping.", tint: "violet" },
              children: [
                {
                  id: "TASK-5", type: "task", title: "Build agent approval queue view",
                  desc: "Filterable queue, bulk approve, SLA timer.",
                  priority: "Medium", points: 3, status: "pending",
                  steps: [
                    "Build a filterable queue (status, value, age).",
                    "Single-screen detail: order + reason + condition photos.",
                    "Add a bulk-approve action with a confirmation step.",
                    "Add an SLA timer that highlights overdue items.",
                  ],
                  notes: "The queue must reflect new scan-ins in near-real-time (≤ 30s).",
                  source: { ts: "23:30", tint: "violet" }, children: [],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      id: "EPIC-2",
      type: "epic",
      title: "Returns Analytics Dashboard",
      desc: "Give merchandising and ops visibility into return rates, reasons, and cost so they can act on recurring problems.",
      priority: "Medium",
      status: "pending",
      value: "Turns return events into merchandising signal — surfacing which SKUs and reasons drive cost so teams fix root causes instead of just processing refunds.",
      metrics: [
        "Merch can identify the top-10 returned SKUs in under a minute",
        "Reason data attached to ≥ 95% of returns",
        "At least one SKU-level action taken per merch review cycle",
      ],
      scopeIn: [
        "Return rate by SKU / category / reason",
        "Trend over time with date filters",
        "CSV export for offline analysis",
      ],
      scopeOut: ["Predictive return forecasting", "Automated SKU delisting"],
      deps: ["Returns data warehouse", "Shared reason taxonomy"],
      questions: ["What minimum volume makes a SKU's return rate statistically meaningful?"],
      source: { ts: "34:58", quote: "None of this matters if merch can't see which SKUs are coming back and why.", tint: "violet" },
      children: [
        {
          id: "FEAT-3",
          type: "feature",
          title: "Return-rate reporting",
          desc: "Dashboards breaking down return rate by SKU, category, and reason over time.",
          priority: "Medium",
          status: "pending",
          value: "Gives merchandisers a self-serve way to spot quality problems weekly instead of waiting on ad-hoc data pulls.",
          flows: [
            "Open dashboard → SKU table sorted by return rate",
            "Expand a SKU → reason breakdown",
            "Adjust the date range → table and trend update",
          ],
          deps: ["Nightly aggregation job", "Reporting warehouse access"],
          questions: ["Default date range — trailing 4 weeks or current quarter?"],
          source: { ts: "37:11", quote: "Top offenders by SKU, sliceable by reason, trending week over week.", tint: "violet" },
          children: [
            {
              id: "US-4",
              type: "story",
              title: "View return rate by SKU",
              desc: "As a merchandiser, I want to see return rate per SKU so that I can flag products with quality issues.",
              priority: "Medium",
              points: 5,
              status: "pending",
              ac: [
                "A table of SKUs is sortable by return rate and volume.",
                "Each row expands to a reason breakdown.",
                "A date-range filter supports week and month granularity.",
              ],
              example: "Sorting by return rate surfaces SKU-4471 (a slim-fit shirt) at 22% returns. Expanding the row shows 70% are 'too small' — pointing at a sizing/spec issue rather than a quality defect.",
              edge: [
                "Low-volume SKUs (< 20 orders) flagged as 'low confidence'.",
                "SKU with returns but missing reasons — shown as 'unspecified'.",
                "Date range spanning a catalog change where a SKU was renumbered.",
              ],
              deps: ["Aggregation job output", "SKU master data"],
              source: { ts: "38:40", tint: "violet" },
              children: [
                {
                  id: "TASK-6", type: "task", title: "Build returns aggregation job",
                  desc: "Nightly rollup into the reporting warehouse.",
                  priority: "Medium", points: 3, status: "pending",
                  steps: [
                    "Define the nightly rollup: returns by SKU × reason × day.",
                    "Write results to a partitioned reporting-warehouse table.",
                    "Backfill the last 12 months.",
                    "Add data-freshness monitoring with an alert.",
                  ],
                  notes: "Make re-runs idempotent and partition by day for cheap date-range queries.",
                  source: { ts: "39:50", tint: "violet" }, children: [],
                },
                {
                  id: "TASK-7", type: "task", title: "SKU return-rate table component",
                  desc: "Sortable, expandable rows, CSV export.",
                  priority: "Low", points: 2, status: "pending",
                  steps: [
                    "Sortable columns for return rate and volume.",
                    "Expandable rows revealing the reason breakdown.",
                    "CSV export of the current view.",
                    "Empty and low-confidence states.",
                  ],
                  source: { ts: "40:30", tint: "violet" }, children: [],
                },
              ],
            },
          ],
        },
      ],
    },
  ];

  const TYPE = {
    epic: { label: "Epic", color: "#d9730d", soft: "#fbeede", letter: "E" },
    feature: { label: "Feature", color: "#8957a8", soft: "#f1e9f6", letter: "F" },
    story: { label: "User Story", color: "#1d77c4", soft: "#e3f0fb", letter: "S" },
    task: { label: "Task", color: "#b8860b", soft: "#f7eed2", letter: "T" },
  };

  const PRIORITY = {
    High: { color: "#d4382f", soft: "#fbe7e6" },
    Medium: { color: "#c2790a", soft: "#fbf0db" },
    Low: { color: "#5b6472", soft: "#eef0f3" },
  };

  // People → initials + color for avatars
  const PEOPLE = {
    "Priya Raman": "#6366f1",
    "Devon Clarke": "#0ea5a4",
    "Mara Ng": "#e0701b",
    "Sam Whitfield": "#8957a8",
    "Lola Fischer": "#d4467f",
    "Yusuf Adeyemi": "#2563eb",
    "Aria Patel": "#0891b2",
    "Tom Becker": "#65a30d",
  };

  window.AG = { meetings, tree, TYPE, PRIORITY, PEOPLE };
})();
