/* Agent Genesis — hierarchy tree (Epic > Feature > Story > Task) */

function countStatus(nodes, acc = { total: 0, approved: 0 }) {
  for (const n of nodes) {
    acc.total += 1;
    if (n.status === "approved") acc.approved += 1;
    if (n.children) countStatus(n.children, acc);
  }
  return acc;
}

function TreeView({ data, expanded, onToggle, focusedId, onFocus, onApprove, onJump, hierarchyStyle, density, recentId }) {
  return (
    <div className={`tree tree--${hierarchyStyle} tree--${density}`}>
      {data.map((n) => (
        <TreeNode key={n.id} node={n} depth={0} expanded={expanded} onToggle={onToggle}
                  focusedId={focusedId} onFocus={onFocus} onApprove={onApprove} onJump={onJump}
                  hierarchyStyle={hierarchyStyle} recentId={recentId} />
      ))}
    </div>
  );
}

function TreeNode({ node, depth, expanded, onToggle, focusedId, onFocus, onApprove, onJump, hierarchyStyle, recentId }) {
  const hasKids = node.children && node.children.length > 0;
  const isOpen = expanded.has(node.id);
  const isFocused = focusedId === node.id;
  const t = window.AG.TYPE[node.type];
  const childCount = hasKids ? node.children.length : 0;
  const sub = hasKids ? countStatus(node.children) : null;
  const showDetail = isFocused;

  return (
    <div className={`tnode tnode--${node.type} ${isFocused ? "is-focused" : ""} ${node.status === "approved" ? "is-approved" : ""} ${recentId === node.id ? "is-recent" : ""}`}>
      <div className="tnode__row" onClick={() => onFocus(node.id)} style={{ "--accent": t.color }}>
        <div className="tnode__caret" onClick={(e) => { e.stopPropagation(); if (hasKids) onToggle(node.id); }}>
          {hasKids ? (
            <span className={`tnode__caretico ${isOpen ? "is-open" : ""}`}><Icons.Chevron size={15} /></span>
          ) : <span className="tnode__caretdot" />}
        </div>

        <TypeGlyph type={node.type} size={node.type === "epic" ? 26 : node.type === "feature" ? 24 : 22} />

        <div className="tnode__body">
          <div className="tnode__line1">
            <span className="tnode__title">{node.title}</span>
            <span className="tnode__id">{node.id}</span>
          </div>
          <div className="tnode__line2">
            <TypePill type={node.type} size="sm" />
            {node.priority && <PriorityTag priority={node.priority} />}
            {node.points != null && <Points value={node.points} />}
            {hasKids && (
              <span className="tnode__kids">
                {childCount} {node.type === "epic" ? "features" : node.type === "feature" ? "stories" : "tasks"}
              </span>
            )}
            {node.ac && node.ac.length > 0 && <span className="tnode__ac"><Icons.Check size={12} sw={2.4} /> {node.ac.length} AC</span>}
            <SourceChip source={node.source} onJump={(e) => { e.stopPropagation(); onJump(node); }} />
          </div>
        </div>

        <div className="tnode__right">
          {sub && (
            <span className="tnode__prog" title={`${sub.approved} of ${sub.total} child items approved`}>
              {sub.approved}/{sub.total}
            </span>
          )}
          <ApproveBox status={node.status} onClick={(e) => { e.stopPropagation(); onApprove(node.id); }} />
        </div>
      </div>

      {showDetail && (
        <div className="tnode__detail" onClick={(e) => e.stopPropagation()}>
          <NodeDetail node={node} onJump={onJump} />
        </div>
      )}

      {hasKids && isOpen && (
        <div className="tnode__children">
          {node.children.map((c) => (
            <TreeNode key={c.id} node={c} depth={depth + 1} expanded={expanded} onToggle={onToggle}
                      focusedId={focusedId} onFocus={onFocus} onApprove={onApprove} onJump={onJump}
                      hierarchyStyle={hierarchyStyle} recentId={recentId} />
          ))}
        </div>
      )}
    </div>
  );
}

function DetailSection({ label, children }) {
  return (
    <div className="tnode__section">
      <div className="tnode__achead">{label}</div>
      {children}
    </div>
  );
}

// Shared rich-detail body — used inline in the Nested view and inside the Board drawer.
function NodeDetail({ node, onJump }) {
  return (
    <React.Fragment>
      {node.desc && <p className="tnode__desc">{node.desc}</p>}

      {node.value && (
        <DetailSection label="Business value">
          <p className="tnode__para">{node.value}</p>
        </DetailSection>
      )}

      {node.metrics && node.metrics.length > 0 && (
        <DetailSection label="Success metrics">
          <ul className="tnode__list tnode__list--check">
            {node.metrics.map((m, i) => <li key={i}><Icons.Check size={13} sw={2.4} />{m}</li>)}
          </ul>
        </DetailSection>
      )}

      {(node.scopeIn || node.scopeOut) && (
        <DetailSection label="Scope">
          <div className="tnode__scope">
            {node.scopeIn && (
              <div className="tnode__scopecol tnode__scopecol--in">
                <div className="tnode__scopehd tnode__scopehd--in">In scope</div>
                <ul>{node.scopeIn.map((s, i) => <li key={i}>{s}</li>)}</ul>
              </div>
            )}
            {node.scopeOut && (
              <div className="tnode__scopecol tnode__scopecol--out">
                <div className="tnode__scopehd tnode__scopehd--out">Out of scope</div>
                <ul>{node.scopeOut.map((s, i) => <li key={i}>{s}</li>)}</ul>
              </div>
            )}
          </div>
        </DetailSection>
      )}

      {node.flows && node.flows.length > 0 && (
        <DetailSection label="Key flows">
          <ol className="tnode__steps">{node.flows.map((s, i) => <li key={i}>{s}</li>)}</ol>
        </DetailSection>
      )}

      {node.ac && node.ac.length > 0 && (
        <DetailSection label="Acceptance criteria">
          <ul className="tnode__aclist">
            {node.ac.map((a, i) => <li key={i}><span className="tnode__acgiven">{["Given","When","Then","And"][i] || "And"}</span>{a}</li>)}
          </ul>
        </DetailSection>
      )}

      {node.example && (
        <DetailSection label="Example scenario">
          <div className="tnode__example">
            <Icons.Sparkle size={13} />
            <p>{node.example}</p>
          </div>
        </DetailSection>
      )}

      {node.edge && node.edge.length > 0 && (
        <DetailSection label="Edge cases & considerations">
          <ul className="tnode__list tnode__list--dot">{node.edge.map((e, i) => <li key={i}>{e}</li>)}</ul>
        </DetailSection>
      )}

      {node.steps && node.steps.length > 0 && (
        <DetailSection label={node.type === "task" ? "Implementation steps" : "Steps"}>
          <ol className="tnode__steps">{node.steps.map((s, i) => <li key={i}>{s}</li>)}</ol>
        </DetailSection>
      )}

      {node.notes && (
        <DetailSection label="Technical notes">
          <p className="tnode__note">{node.notes}</p>
        </DetailSection>
      )}

      {node.deps && node.deps.length > 0 && (
        <DetailSection label="Dependencies">
          <div className="tnode__deps">
            {node.deps.map((d, i) => <span key={i} className="tnode__dep"><Icons.Link size={12} />{d}</span>)}
          </div>
        </DetailSection>
      )}

      {node.questions && node.questions.length > 0 && (
        <DetailSection label="Open questions">
          <ul className="tnode__list tnode__list--q">{node.questions.map((q, i) => <li key={i}>{q}</li>)}</ul>
        </DetailSection>
      )}

      {node.source && node.source.quote && (
        <DetailSection label="Where this came from">
          <div className={`tnode__quote ${onJump ? "tnode__quote--jump" : ""}`} onClick={onJump ? (e) => { e.stopPropagation(); onJump(node); } : undefined}>
            <FrameThumb ts={node.source.ts} tint={node.source.tint} w={104} h={62} />
            <div className="tnode__quotetxt">
              <div className="tnode__quotelabel"><Icons.Play size={11} /> Extracted from {node.source.ts}</div>
              <p>“{node.source.quote}”</p>
            </div>
          </div>
        </DetailSection>
      )}
    </React.Fragment>
  );
}

window.TreeView = TreeView;
window.NodeDetail = NodeDetail;
window.countStatus = countStatus;
