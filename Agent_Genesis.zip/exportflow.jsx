/* Agent Genesis — Azure DevOps export flow (modal) */

function flatten(nodes, acc = []) {
  for (const n of nodes) { acc.push(n); if (n.children) flatten(n.children, acc); }
  return acc;
}

function ExportFlow({ items, onClose }) {
  const [step, setStep] = React.useState("config"); // config | preview | pushing | done
  const [org] = React.useState("contoso");
  const [project, setProject] = React.useState("Retail Platform");
  const [areaPath, setAreaPath] = React.useState("Retail Platform\\Returns");
  const [iteration, setIteration] = React.useState("Sprint 24");
  const [progress, setProgress] = React.useState(0);

  const flat = flatten(items);
  const counts = flat.reduce((a, n) => { a[n.type] = (a[n.type] || 0) + 1; return a; }, {});
  const order = ["epic", "feature", "story", "task"];

  const mapping = [
    { from: "Title", to: "Title", ico: <Icons.Edit size={13} /> },
    { from: "Description", to: "Description", ico: <Icons.Transcript size={13} /> },
    { from: "Acceptance criteria", to: "Acceptance Criteria", ico: <Icons.Check size={13} sw={2.4} /> },
    { from: "Story points", to: "Story Points", ico: <Icons.Layers size={13} /> },
    { from: "Priority", to: "Priority", ico: <Icons.Flag size={13} /> },
    { from: "Source timestamp", to: "Tag + Comment link", ico: <Icons.Play size={13} /> },
  ];

  const start = () => {
    setStep("pushing"); setProgress(0);
    const total = flat.length;
    let i = 0;
    const iv = setInterval(() => {
      i += 1;
      setProgress(Math.round((i / total) * 100));
      if (i >= total) { clearInterval(iv); setTimeout(() => setStep("done"), 500); }
    }, 260);
  };

  return (
    <div className="modal">
      <div className="export" onClick={(e) => e.stopPropagation()}>
        <div className="export__head">
          <div className="export__headl">
            <AzureDevOpsLogo size={22} />
            <div>
              <div className="export__title">Export to Azure DevOps</div>
              <div className="export__sub">{flat.length} approved work items · {org}</div>
            </div>
          </div>
          <button className="modal__close" onClick={onClose}><Icons.Close size={18} /></button>
        </div>

        <div className="export__steps">
          {[["config","Configure"],["preview","Preview"],["done","Create"]].map(([k,label],i) => {
            const idx = ["config","preview","done"].indexOf(step === "pushing" ? "done" : step);
            const me = ["config","preview","done"].indexOf(k);
            return <div key={k} className={`exstep ${me<idx?"is-done":me===idx?"is-active":""}`}><span className="exstep__n">{me<idx?<Icons.Check size={12} sw={2.6}/>:i+1}</span>{label}</div>;
          })}
        </div>

        <div className="export__body">
          {step === "config" && (
            <div className="export__config">
              <div className="export__grid">
                <Field label="Organization"><div className="export__static"><AzureDevOpsLogo size={15} /> dev.azure.com/{org}</div></Field>
                <Field label="Project"><Select value={project} onChange={setProject} options={["Retail Platform","Growth","Search Platform"]} /></Field>
                <Field label="Area path"><Select value={areaPath} onChange={setAreaPath} options={["Retail Platform\\Returns","Retail Platform\\Checkout","Retail Platform"]} /></Field>
                <Field label="Iteration path"><Select value={iteration} onChange={setIteration} options={["Sprint 24","Sprint 25","Backlog"]} /></Field>
              </div>

              <div className="export__maptitle">Field mapping</div>
              <div className="maptable">
                <div className="maptable__head"><span>Agent Genesis</span><span /><span>Azure DevOps work item</span></div>
                {mapping.map((m) => (
                  <div className="maptable__row" key={m.from}>
                    <span className="maptable__from">{m.ico} {m.from}</span>
                    <span className="maptable__arrow"><Icons.Arrow size={15} /></span>
                    <span className="maptable__to">{m.to}</span>
                  </div>
                ))}
              </div>
              <label className="export__opt"><span className="export__optbox is-on"><Icons.Check size={12} sw={2.6} /></span> Link each item back to its meeting moment as a comment</label>
            </div>
          )}

          {step === "preview" && (
            <div className="export__preview">
              <div className="export__summary">
                {order.filter((t)=>counts[t]).map((t) => (
                  <div key={t} className="export__sumcard" style={{ "--c": window.AG.TYPE[t].color }}>
                    <span className="export__sumn">{counts[t]}</span>
                    <span className="export__sumt">{window.AG.TYPE[t].label}{counts[t]>1?"s":""}</span>
                  </div>
                ))}
              </div>
              <div className="export__previewlist">
                {flat.map((n) => (
                  <div key={n.id} className="exprev" style={{ paddingLeft: 14 + order.indexOf(n.type) * 22 }}>
                    <TypeGlyph type={n.type} size={20} />
                    <span className="exprev__title">{n.title}</span>
                    {n.points!=null && <Points value={n.points} />}
                    {n.priority && <PriorityTag priority={n.priority} />}
                    <span className="exprev__new">new</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {step === "pushing" && (
            <div className="export__pushing">
              <div className="export__pushorb"><AzureDevOpsLogo size={30} /></div>
              <div className="export__pushtitle">Creating work items in {project}…</div>
              <div className="export__bar"><div className="export__barfill" style={{ width: progress + "%" }} /></div>
              <div className="export__pushpct">{progress}%</div>
            </div>
          )}

          {step === "done" && (
            <div className="export__done">
              <div className="export__donecheck"><Icons.Check size={30} sw={2.6} /></div>
              <h2>{flat.length} work items created</h2>
              <p>Synced to <b>{project}</b> · {areaPath.replace(/\\/g," / ")} · {iteration}</p>
              <div className="export__donelist">
                {flat.slice(0, 5).map((n, i) => (
                  <div key={n.id} className="exdone">
                    <TypePill type={n.type} size="sm" />
                    <span className="exdone__title">{n.title}</span>
                    <span className="exdone__id">AB#{2400 + i}</span>
                  </div>
                ))}
                {flat.length > 5 && <div className="exdone exdone--more">+{flat.length - 5} more created</div>}
              </div>
            </div>
          )}
        </div>

        <div className="export__foot">
          {step === "config" && <><Btn variant="ghost" onClick={onClose}>Cancel</Btn><Btn variant="primary" iconRight={<Icons.Arrow size={16} />} onClick={() => setStep("preview")}>Review {flat.length} items</Btn></>}
          {step === "preview" && <><Btn variant="ghost" onClick={() => setStep("config")}>Back</Btn><Btn variant="primary" icon={<AzureDevOpsLogo size={16} />} onClick={start}>Create in Azure DevOps</Btn></>}
          {step === "pushing" && <Btn variant="ghost" disabled>Creating…</Btn>}
          {step === "done" && <><Btn variant="ghost" onClick={onClose}>Close</Btn><Btn variant="primary" iconRight={<Icons.Link size={15} />} onClick={onClose}>Open board in Azure DevOps</Btn></>}
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return <label className="field"><span className="field__label">{label}</span>{children}</label>;
}
function Select({ value, onChange, options }) {
  return (
    <div className="agselect">
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((o) => <option key={o} value={o}>{o.replace(/\\/g, " / ")}</option>)}
      </select>
      <Icons.ChevronDown size={15} />
    </div>
  );
}

window.ExportFlow = ExportFlow;
