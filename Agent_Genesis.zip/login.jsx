/* Agent Genesis — Login (Microsoft auth) */
function LoginScreen({ onSignIn }) {
  const [busy, setBusy] = React.useState(false);
  const [stage, setStage] = React.useState(null); // 'picker' | 'connecting'

  const handle = () => {
    setStage("picker");
  };
  const pick = () => {
    setBusy(true);
    setStage("connecting");
    setTimeout(() => onSignIn(), 1500);
  };

  return (
    <div className="login">
      <div className="login__art" aria-hidden="true">
        <div className="login__aurora" />
        <div className="login__grid" />
        <div className="login__brandbig">
          <AgentMark size={40} />
          <span>Agent Genesis</span>
        </div>
        <div className="login__pitch">
          <h2>From conversation to backlog.</h2>
          <p>Turn recorded product meetings into a structured, review-ready hierarchy of epics, features, stories, and tasks — then ship them straight to Azure DevOps.</p>
        </div>
        <div className="login__flowmini">
          <div className="login__flowstep"><TeamsLogo size={16} /> Meeting</div>
          <span className="login__flowarrow"><Icons.Arrow size={15} /></span>
          <div className="login__flowstep"><AgentMark size={15} /> Agent</div>
          <span className="login__flowarrow"><Icons.Arrow size={15} /></span>
          <div className="login__flowstep"><AzureDevOpsLogo size={15} /> Boards</div>
        </div>
      </div>

      <div className="login__panel">
        <div className="login__card">
          <div className="login__brand">
            <AgentMark size={26} />
            <span>Agent Genesis</span>
          </div>
          <h1>Sign in</h1>
          <p className="login__sub">Use your work account to access your meeting records.</p>

          {stage !== "connecting" && (
            <button className="msbtn" onClick={stage === "picker" ? null : handle} disabled={stage === "picker"}>
              <MicrosoftLogo size={19} />
              <span>Sign in with Microsoft</span>
            </button>
          )}

          {stage === "picker" && (
            <div className="msacct">
              <div className="msacct__head">Pick an account</div>
              <button className="msacct__row" onClick={pick}>
                <Avatar name="Priya Raman" size={34} />
                <div className="msacct__info">
                  <div className="msacct__name">Priya Raman</div>
                  <div className="msacct__mail">priya.raman@contoso.com</div>
                </div>
                <Icons.Chevron size={16} style={{ color: "var(--faint)" }} />
              </button>
              <button className="msacct__row msacct__row--other" onClick={pick}>
                <div className="msacct__plus"><Icons.Plus size={16} /></div>
                <div className="msacct__info"><div className="msacct__name">Use another account</div></div>
              </button>
            </div>
          )}

          {stage === "connecting" && (
            <div className="login__connecting">
              <Spinner size={20} />
              <span>Signing you in…</span>
            </div>
          )}

          <div className="login__scopes">
            <div className="login__scopesh"><Icons.Shield size={14} /> Agent Genesis will be able to</div>
            <ul>
              <li><Icons.Check size={13} sw={2.4} /> Read your Teams meeting recordings & transcripts</li>
              <li><Icons.Check size={13} sw={2.4} /> Read your profile and organization directory</li>
            </ul>
            <p className="login__consent">You can revoke access anytime from your Microsoft account. We never modify your recordings.</p>
          </div>
        </div>
        <div className="login__legal">By continuing you agree to the <a href="#a" onClick={(e)=>e.preventDefault()}>Terms</a> and <a href="#a" onClick={(e)=>e.preventDefault()}>Privacy Policy</a>.</div>
      </div>
    </div>
  );
}
window.LoginScreen = LoginScreen;
