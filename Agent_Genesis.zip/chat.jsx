/* Agent Genesis — AI chat dock with applyable edits */

function buildResponse(text, node) {
  const q = text.toLowerCase();
  // returns { reply, suggestion? }  suggestion: { summary, detail, action }
  if (node && (q.includes("acceptance") || q.includes("criteria") || q.includes(" ac"))) {
    return {
      reply: `Looking at “${node.title}”, the criteria don't cover the unhappy paths. I'd add coverage for an empty / ineligible state and a confirmation. Want me to apply these?`,
      suggestion: {
        summary: `Add 2 acceptance criteria to ${node.id}`,
        items: [
          "If no eligible items exist, an empty state explains why and offers support contact.",
          "On success, the customer sees a confirmation with a reference number.",
        ],
        action: { kind: "addAC", nodeId: node.id, items: [
          "If no eligible items exist, an empty state explains why and offers support contact.",
          "On success, the customer sees a confirmation with a reference number.",
        ] },
      },
    };
  }
  if (node && node.type === "story" && (q.includes("split") || q.includes("too big") || q.includes("break"))) {
    return {
      reply: `“${node.title}” is carrying two concerns. I'd split out the label-generation path into its own story so each stays independently shippable.`,
      suggestion: {
        summary: `Split ${node.id} into a second story`,
        items: ["New story: “Handle ineligible & expired return windows” (3 pts)"],
        action: { kind: "addStory", parentId: node._parentId, story: {
          title: "Handle ineligible & expired return windows", points: 3, priority: "Medium",
          desc: "As a customer, I want clear messaging when an item can't be returned so that I'm not stuck guessing.",
          ac: ["Items past the 30-day window show a disabled control with the reason.", "An explainer links to the full returns policy."],
        } },
      },
    };
  }
  if (node && (q.includes("priority") || q.includes("high") || q.includes("urgent"))) {
    return {
      reply: `Got it — bumping “${node.title}” to High priority.`,
      suggestion: { summary: `Set ${node.id} priority → High`, items: [], action: { kind: "setField", nodeId: node.id, field: "priority", value: "High" } },
    };
  }
  if (node && (q.includes("task") || q.includes("subtask"))) {
    return {
      reply: `I'll add an engineering task under “${node.title}” to cover the analytics instrumentation, which the meeting flagged but the draft missed.`,
      suggestion: { summary: `Add task to ${node.id}`, items: ["New task: “Instrument funnel analytics events” (2 pts)"],
        action: { kind: "addTask", parentId: node.id, task: { title: "Instrument funnel analytics events", points: 2, priority: "Low", desc: "Emit start/step/complete events for the return flow." } } },
    };
  }
  if (q.includes("duplicate") || q.includes("merge")) {
    return { reply: "I scanned all four levels — no clear duplicates right now. The two reporting stories overlap slightly on the aggregation job, but they're distinct enough to keep separate." };
  }
  if (q.includes("missing") || q.includes("gap") || q.includes("what else")) {
    return { reply: "Two gaps stand out from the transcript: there's no story for return *status tracking* after a label is generated, and no error handling for failed carrier API calls. Want me to draft either?" };
  }
  if (q.includes("summar") || q.includes("overview")) {
    return { reply: "This backlog has 2 epics, 3 features, 4 user stories and 7 tasks (28 points). The Returns Portal epic is the bulk of the value; the Analytics epic is smaller and could be a fast-follow. Roughly 1.5–2 sprints for one squad." };
  }
  if (node) {
    return { reply: `On “${node.title}” — I can tighten the wording, add acceptance criteria, split it, re-estimate, or add tasks. What would help?` };
  }
  return { reply: "Select any item in the tree and I'll help you refine it — or ask me to find gaps, spot duplicates, or re-estimate the whole backlog." };
}

function quickActions(node) {
  if (!node) return ["Summarize the backlog", "What's missing?", "Find duplicates"];
  if (node.type === "story") return ["Add acceptance criteria", "Split this story", "Add a task", "Make it High priority"];
  if (node.type === "task") return ["Add detail", "Re-estimate this", "Make it High priority"];
  return ["Add acceptance criteria", "What's missing here?", "Tighten the description"];
}

function ChatDock({ focusedNode, onApplyAction, chatStyle, onCollapse }) {
  const [messages, setMessages] = React.useState([
    { id: 1, from: "ai", text: "I drafted a backlog from the Returns Portal workshop — 2 epics down to 7 tasks, with acceptance criteria and estimates pulled from the discussion. Select anything to refine it, or ask me to find gaps." },
  ]);
  const [input, setInput] = React.useState("");
  const [thinking, setThinking] = React.useState(false);
  const scroller = React.useRef(null);

  React.useEffect(() => {
    if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [messages, thinking]);

  const send = (textArg) => {
    const text = (textArg || input).trim();
    if (!text || thinking) return;
    const userMsg = { id: Date.now(), from: "user", text };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setThinking(true);
    const node = focusedNode;
    setTimeout(() => {
      const res = buildResponse(text, node);
      setThinking(false);
      setMessages((m) => [...m, { id: Date.now() + 1, from: "ai", text: res.reply, suggestion: res.suggestion, applied: false }]);
    }, 950);
  };

  const apply = (msgId, suggestion) => {
    const ok = onApplyAction(suggestion.action);
    if (ok) setMessages((m) => m.map((x) => x.id === msgId ? { ...x, applied: true } : x));
  };
  const dismiss = (msgId) => setMessages((m) => m.map((x) => x.id === msgId ? { ...x, dismissed: true, suggestion: null } : x));

  return (
    <aside className={`chat chat--${chatStyle}`}>
      <div className="chat__head">
        <div className="chat__headleft">
          <div className="chat__avatar"><AgentMark size={18} /></div>
          <div>
            <div className="chat__title">Agent</div>
            <div className="chat__status"><span className="chat__dot" /> Ready</div>
          </div>
        </div>
        <div className="chat__headbtns">
          <button className="chat__iconbtn" title="Clear conversation" onClick={() => setMessages(messages.slice(0,1))}><Icons.Edit size={15} /></button>
          {onCollapse && <button className="chat__iconbtn" title="Collapse chat" onClick={onCollapse}><Icons.PanelRight size={15} /></button>}
        </div>
      </div>

      {focusedNode && (
        <div className="chat__context">
          <span className="chat__ctxlabel">Editing</span>
          <TypePill type={focusedNode.type} size="sm" />
          <span className="chat__ctxtitle">{focusedNode.title}</span>
        </div>
      )}

      <div className="chat__scroll" ref={scroller}>
        {messages.map((m) => (
          <div key={m.id} className={`msg msg--${m.from}`}>
            {m.from === "ai" && <div className="msg__avatar"><AgentMark size={15} /></div>}
            <div className="msg__col">
              <div className="msg__bubble">{m.text}</div>
              {m.suggestion && !m.applied && (
                <div className="sugg">
                  <div className="sugg__head"><Icons.Wand size={14} /> {m.suggestion.summary}</div>
                  {m.suggestion.items.length > 0 && (
                    <ul className="sugg__items">{m.suggestion.items.map((it, i) => <li key={i}><Icons.Plus size={12} /> {it}</li>)}</ul>
                  )}
                  <div className="sugg__actions">
                    <Btn variant="primary" size="sm" icon={<Icons.Check size={14} sw={2.4} />} onClick={() => apply(m.id, m.suggestion)}>Apply</Btn>
                    <Btn variant="ghost" size="sm" onClick={() => dismiss(m.id)}>Dismiss</Btn>
                  </div>
                </div>
              )}
              {m.applied && <div className="msg__applied"><Icons.CheckCircle size={14} /> Applied to the backlog</div>}
            </div>
          </div>
        ))}
        {thinking && (
          <div className="msg msg--ai">
            <div className="msg__avatar"><AgentMark size={15} /></div>
            <div className="msg__bubble msg__bubble--think"><span className="typedot" /><span className="typedot" /><span className="typedot" /></div>
          </div>
        )}
      </div>

      <div className="chat__quick">
        {quickActions(focusedNode).map((a) => (
          <button key={a} className="chat__chip" onClick={() => send(a)}>{a}</button>
        ))}
      </div>

      <div className="chat__inputbar">
        <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()}
               placeholder={focusedNode ? `Refine “${focusedNode.title}”…` : "Ask the agent to refine the backlog…"} />
        <button className="chat__send" onClick={() => send()} disabled={!input.trim()}><Icons.Send size={16} /></button>
      </div>
    </aside>
  );
}

window.ChatDock = ChatDock;
