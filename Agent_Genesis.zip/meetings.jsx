/* Agent Genesis — Home shell: Meetings / Stories / Dashboard tabs */
function HomeScreen({ extractedIds, activeTab, onTab, onGenerate, onOpenBacklog, onSignOut }) {
  const all = window.AG.meetings;
  const pendingMeetings = all.filter((m) => !extractedIds.has(m.id));
  const doneMeetings = all.filter((m) => extractedIds.has(m.id));

  const tabs = [
    { id: "meetings", label: "Meetings", icon: <Icons.Video size={16} />, count: pendingMeetings.length },
    { id: "stories", label: "Stories", icon: <Icons.Layers size={16} />, count: doneMeetings.length },
    { id: "dashboard", label: "Dashboard", icon: <Icons.Grid size={16} />, count: null },
  ];

  const titles = {
    meetings: ["Meetings to analyze", "Recordings Agent Genesis can read. Pick one or more and generate a backlog."],
    stories: ["Extracted backlogs", "Meetings already turned into a hierarchy of epics, features, stories, and tasks."],
    dashboard: ["Dashboard", "A snapshot of everything Agent Genesis has processed for your team."],
  };

  return (
    <div className="screen home">
      <AppHeader onSignOut={onSignOut} />

      <div className="home__body">
        <div className="home__inner">
          <div className="home__head">
            <h1>{titles[activeTab][0]}</h1>
            <p>{titles[activeTab][1]}</p>
          </div>

          <nav className="hometabs">
            {tabs.map((t) => (
              <button key={t.id} className={`hometab ${activeTab === t.id ? "is-active" : ""}`} onClick={() => onTab(t.id)}>
                {t.icon}
                <span>{t.label}</span>
                {t.count != null && <span className="hometab__count">{t.count}</span>}
              </button>
            ))}
          </nav>

          {activeTab === "meetings" && <MeetingsTab meetings={pendingMeetings} onGenerate={onGenerate} />}
          {activeTab === "stories" && <StoriesTab meetings={doneMeetings} onOpenBacklog={onOpenBacklog} onGoMeetings={() => onTab("meetings")} />}
          {activeTab === "dashboard" && <DashboardTab pending={pendingMeetings} done={doneMeetings} />}
        </div>
      </div>
    </div>
  );
}

function TabNote({ icon, title, text }) {
  return (
    <div className="tabnote">
      <span className="tabnote__icon">{icon}</span>
      <div>
        <div className="tabnote__title">{title}</div>
        <p className="tabnote__text">{text}</p>
      </div>
    </div>
  );
}

/* ---------- Meetings tab: not-yet-extracted recordings ---------- */
function MeetingsTab({ meetings, onGenerate }) {
  const [selected, setSelected] = React.useState(() => new Set());
  const [query, setQuery] = React.useState("");
  const [view, setView] = React.useState("list");
  const [onlyVideo, setOnlyVideo] = React.useState(false);
  const [uploadOpen, setUploadOpen] = React.useState(false);

  const toggle = (id) => setSelected((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const filtered = meetings.filter((m) => {
    if (onlyVideo && !m.hasVideo) return false;
    if (!query) return true;
    const q = query.toLowerCase();
    return m.title.toLowerCase().includes(q) || m.channel.toLowerCase().includes(q) || m.organizer.toLowerCase().includes(q);
  });
  const selectedMeetings = meetings.filter((m) => selected.has(m.id));

  return (
    <React.Fragment>
      <TabNote icon={<Icons.Sparkle size={16} />}
        title="These haven’t been extracted yet"
        text="Every meeting here is still raw — Agent Genesis hasn’t turned it into stories. Select the ones you want, then Generate user stories. Once extracted, a meeting moves to the Stories tab." />

      <button className="uploadcta" onClick={() => setUploadOpen(true)}>
        <span className="uploadcta__icon"><Icons.Upload size={20} /></span>
        <span className="uploadcta__txt">
          <span className="uploadcta__title">Upload your own video</span>
          <span className="uploadcta__sub">Have a recording that isn’t synced from Teams? Upload it and Agent Genesis will extract user stories from it.</span>
        </span>
        <span className="uploadcta__btn"><Icons.Plus size={16} /> Upload video</span>
      </button>

      {meetings.length === 0 ? (
        <div className="emptytab">
          <Icons.CheckCircle size={30} />
          <div className="emptytab__title">You’re all caught up</div>
          <p>Every available meeting has already been extracted. Check the Stories tab to review their backlogs.</p>
        </div>
      ) : (
        <React.Fragment>
          <div className="meetings__toolbar">
            <div className="ag-searchbox">
              <Icons.Search size={16} />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search meetings, channels, organizers…" />
            </div>
            <button className={`ag-chiptoggle ${onlyVideo ? "is-on" : ""}`} onClick={() => setOnlyVideo((v) => !v)}>
              <Icons.Video size={15} /> Has video
            </button>
            <div className="meetings__spacer" />
            <Btn variant="default" icon={<Icons.Upload size={16} />} onClick={() => setUploadOpen(true)}>Upload video</Btn>
            <Segmented value={view} onChange={setView} options={[
              { value: "list", icon: <Icons.List size={16} /> },
              { value: "grid", icon: <Icons.Grid size={16} /> },
            ]} />
          </div>

          <div className={`meetings__list ${view === "grid" ? "is-grid" : ""}`}>
            {filtered.map((m) => (
              <MeetingRow key={m.id} m={m} view={view} checked={selected.has(m.id)} onToggle={() => toggle(m.id)} />
            ))}
            {filtered.length === 0 && <div className="meetings__empty">No meetings match your filters.</div>}
          </div>

          <div className={`selbar ${selected.size ? "is-up" : ""}`}>
            <div className="selbar__inner">
              <div className="selbar__count">
                <span className="selbar__num">{selected.size}</span>
                <span>{selected.size === 1 ? "meeting" : "meetings"} selected</span>
                {selectedMeetings.length > 0 && <span className="selbar__names">{selectedMeetings.map((m) => m.title).join(" · ")}</span>}
              </div>
              <div className="selbar__actions">
                <Btn variant="ghost" onClick={() => setSelected(new Set())}>Clear</Btn>
                <Btn variant="primary" icon={<AgentMark size={16} />} iconRight={<Icons.Arrow size={16} />}
                     onClick={() => onGenerate(selectedMeetings)}>Generate user stories</Btn>
              </div>
            </div>
          </div>
        </React.Fragment>
      )}

      {uploadOpen && <UploadModal onClose={() => setUploadOpen(false)} onExtract={(meeting) => { setUploadOpen(false); onGenerate([meeting]); }} />}
    </React.Fragment>
  );
}

/* ---------- Stories tab: already-extracted meetings ---------- */
function StoriesTab({ meetings, onOpenBacklog, onGoMeetings }) {
  return (
    <React.Fragment>
      <TabNote icon={<Icons.Layers size={16} />}
        title="These meetings have been extracted"
        text="Each card is a generated backlog you can reopen to review, refine with AI, approve items, and export to Azure DevOps. New extractions land here automatically." />

      {meetings.length === 0 ? (
        <div className="emptytab">
          <Icons.Layers size={30} />
          <div className="emptytab__title">No backlogs yet</div>
          <p>Once you extract a meeting it shows up here. Head to the Meetings tab to generate your first backlog.</p>
          <Btn variant="primary" icon={<Icons.Arrow size={16} />} onClick={onGoMeetings}>Go to Meetings</Btn>
        </div>
      ) : (
        <div className="stories__grid">
          {meetings.map((m) => (
            <button key={m.id} className="storycard" onClick={() => onOpenBacklog(m)}>
              <FrameThumb ts={m.duration} tint={m.tint} w={999} h={132} />
              <div className="storycard__body">
                <div className="storycard__top"><TeamsLogo size={14} /> <span>{m.channel}</span></div>
                <div className="storycard__title">{m.title}</div>
                <div className="storycard__stats">
                  <span><b>2</b> epics</span><span className="storycard__dot" />
                  <span><b>4</b> stories</span><span className="storycard__dot" />
                  <span><b>28</b> pts</span>
                </div>
                <div className="storycard__foot">
                  <span className="storycard__date"><Icons.Calendar size={13} /> Extracted {m.date}</span>
                  <span className="storycard__open">Open backlog <Icons.Arrow size={14} /></span>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </React.Fragment>
  );
}

/* ---------- Dashboard tab: overview ---------- */
function DashboardTab({ pending, done }) {
  const tiles = [
    { label: "Awaiting extraction", value: pending.length, sub: "in Meetings", color: "var(--ink)" },
    { label: "Extracted backlogs", value: done.length, sub: "in Stories", color: "var(--primary)" },
    { label: "Work items drafted", value: done.length * 16, sub: "across all backlogs", color: "var(--ink)" },
    { label: "Exported to DevOps", value: 0, sub: "tickets created", color: "var(--ink)" },
  ];
  return (
    <React.Fragment>
      <TabNote icon={<Icons.Grid size={16} />}
        title="Your extraction overview"
        text="Track how many meetings are still waiting, how many have become backlogs, and how much work has been drafted and shipped to Azure DevOps." />

      <div className="dash__tiles">
        {tiles.map((t, i) => (
          <div key={i} className="dashtile">
            <div className="dashtile__value" style={{ color: t.color }}>{t.value}</div>
            <div className="dashtile__label">{t.label}</div>
            <div className="dashtile__sub">{t.sub}</div>
          </div>
        ))}
      </div>
    </React.Fragment>
  );
}

/* ---------- Upload video modal ---------- */
function fmtSize(bytes) {
  if (!bytes) return "";
  const mb = bytes / (1024 * 1024);
  return mb >= 1000 ? (mb / 1024).toFixed(1) + " GB" : mb.toFixed(1) + " MB";
}

const UPLOAD_TINTS = ["blue", "green", "amber", "rose", "violet"];

function UploadModal({ onClose, onExtract }) {
  const [file, setFile] = React.useState(null);
  const [title, setTitle] = React.useState("");
  const [dragging, setDragging] = React.useState(false);
  const [transcript, setTranscript] = React.useState(null);
  const [tDragging, setTDragging] = React.useState(false);
  const inputRef = React.useRef(null);
  const tInputRef = React.useRef(null);

  const pick = (f) => {
    if (!f) return;
    setFile(f);
    if (!title) setTitle(f.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " "));
  };
  const onDrop = (e) => {
    e.preventDefault(); setDragging(false);
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) pick(f);
  };
  const pickTranscript = (f) => { if (f) setTranscript(f); };
  const onDropTranscript = (e) => {
    e.preventDefault(); setTDragging(false);
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) pickTranscript(f);
  };

  const ready = !!file && title.trim().length > 0;
  const extract = () => {
    if (!ready) return;
    const meeting = {
      id: "upload-" + Date.now(),
      title: title.trim(),
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      time: "Uploaded",
      duration: "—",
      organizer: "You",
      attendees: ["You"],
      channel: "Uploaded video",
      hasVideo: true,
      hasTranscript: true,
      transcriptWords: 0,
      tint: UPLOAD_TINTS[Math.floor(Math.random() * UPLOAD_TINTS.length)],
      uploaded: true,
      fileName: file.name,
      transcriptProvided: !!transcript,
      transcriptName: transcript ? transcript.name : null,
    };
    onExtract(meeting);
  };

  return (
    <div className="modal" onClick={onClose}>
      <div className="upload" onClick={(e) => e.stopPropagation()}>
        <button className="modal__close" onClick={onClose}><Icons.Close size={18} /></button>
        <div className="upload__head">
          <span className="upload__headicon"><Icons.Film size={20} /></span>
          <div>
            <h2 className="upload__title">Upload a video</h2>
            <p className="upload__sub">Agent Genesis will transcribe it, sample frames, and extract a story hierarchy — just like a synced meeting.</p>
          </div>
        </div>

        <div className="upload__body">
          <div className="upsection">
            <div className="upsection__head">
              <span className="upsection__step">1</span>
              <div>
                <div className="upsection__title">Video <span className="upsection__req">Required</span></div>
                <div className="upsection__sub">The recording Agent Genesis samples frames from.</div>
              </div>
            </div>
            <input ref={inputRef} type="file" accept="video/*" hidden
                   onChange={(e) => pick(e.target.files && e.target.files[0])} />
            {!file ? (
              <div className={`dropzone ${dragging ? "is-drag" : ""}`}
                   onClick={() => inputRef.current && inputRef.current.click()}
                   onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
                   onDragLeave={() => setDragging(false)}
                   onDrop={onDrop}>
                <span className="dropzone__icon"><Icons.Upload size={26} /></span>
                <div className="dropzone__title">Drag & drop a video here</div>
                <div className="dropzone__or">or <span className="dropzone__browse">browse files</span></div>
                <div className="dropzone__hint">MP4, MOV, or WEBM · up to 2 GB</div>
              </div>
            ) : (
              <div className="upfile">
                <FrameThumb ts="video" tint="blue" w={104} h={62} />
                <div className="upfile__info">
                  <div className="upfile__name">{file.name}</div>
                  <div className="upfile__meta">{fmtSize(file.size)} · video file</div>
                </div>
                <button className="upfile__remove" title="Remove" onClick={() => { setFile(null); if (inputRef.current) inputRef.current.value = ""; }}>
                  <Icons.Close size={16} />
                </button>
              </div>
            )}
          </div>

          <div className="upsection">
            <div className="upsection__head">
              <span className="upsection__step">2</span>
              <div>
                <div className="upsection__title">Transcript <span className="upsection__opt">Recommended</span></div>
                <div className="upsection__sub">Upload your own transcript for faster, more accurate stories — it skips the heavy speech-to-text step.</div>
              </div>
            </div>
            <input ref={tInputRef} type="file" accept=".txt,.vtt,.srt,.docx,.json,text/plain" hidden
                   onChange={(e) => pickTranscript(e.target.files && e.target.files[0])} />
            {!transcript ? (
              <div className={`dropzone dropzone--sm ${tDragging ? "is-drag" : ""}`}
                   onClick={() => tInputRef.current && tInputRef.current.click()}
                   onDragOver={(e) => { e.preventDefault(); setTDragging(true); }}
                   onDragLeave={() => setTDragging(false)}
                   onDrop={onDropTranscript}>
                <span className="dropzone__icon dropzone__icon--sm"><Icons.Transcript size={20} /></span>
                <div className="dropzone__title">Add a transcript file</div>
                <div className="dropzone__hint">VTT, SRT, TXT, or DOCX</div>
              </div>
            ) : (
              <div className="upfile">
                <span className="upfile__doc"><Icons.Transcript size={20} /></span>
                <div className="upfile__info">
                  <div className="upfile__name">{transcript.name}</div>
                  <div className="upfile__meta">{fmtSize(transcript.size)} · transcript</div>
                </div>
                <button className="upfile__remove" title="Remove" onClick={() => { setTranscript(null); if (tInputRef.current) tInputRef.current.value = ""; }}>
                  <Icons.Close size={16} />
                </button>
              </div>
            )}
            {!transcript && (
              <div className="upload__note">
                <Icons.Sparkle size={14} />
                <span>No transcript? Agent Genesis will auto-generate one from the audio — this takes longer and may be less accurate.</span>
              </div>
            )}
          </div>

          <label className="upform">
            <span className="upform__label">Title</span>
            <input className="upform__input" value={title} onChange={(e) => setTitle(e.target.value)}
                   placeholder="e.g. Returns Portal — Discovery Workshop" />
          </label>
        </div>

        <div className="upload__foot">
          <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          <Btn variant="primary" icon={<AgentMark size={16} />} iconRight={<Icons.Arrow size={16} />}
               disabled={!ready} onClick={extract}>Extract user stories</Btn>
        </div>
      </div>
    </div>
  );
}

function MeetingRow({ m, checked, onToggle, view }) {
  return (
    <button className={`mrow ${checked ? "is-checked" : ""} ${view === "grid" ? "mrow--grid" : ""}`} onClick={onToggle}>
      <div className="mrow__check"><span className="mrow__box">{checked && <Icons.Check size={13} sw={2.6} />}</span></div>
      <FrameThumb ts={m.duration} tint={m.tint} w={view === "grid" ? 999 : 128} h={view === "grid" ? 150 : 74} />
      <div className="mrow__main">
        <div className="mrow__top">
          <TeamsLogo size={15} />
          <span className="mrow__channel">{m.channel}</span>
        </div>
        <div className="mrow__title">{m.title}</div>
        <div className="mrow__meta">
          <span><Icons.Calendar size={14} /> {m.date}</span>
          <span><Icons.Clock size={14} /> {m.duration}</span>
          <span className="mrow__org">Organized by {m.organizer}</span>
        </div>
        <div className="mrow__foot">
          <AvatarStack names={m.attendees} size={24} />
          <div className="mrow__badges">
            {m.hasVideo && <span className="mrow__badge"><Icons.Video size={13} /> Video</span>}
            {m.hasTranscript && <span className="mrow__badge"><Icons.Transcript size={13} /> Transcript · {(m.transcriptWords/1000).toFixed(1)}k words</span>}
          </div>
        </div>
      </div>
    </button>
  );
}

window.HomeScreen = HomeScreen;
