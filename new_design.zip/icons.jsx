/* Agent Genesis — icon set (Lucide-style line icons) + brand marks. Exposed to window. */
const Icon = ({ d, size = 18, sw = 1.6, fill = "none", style, children }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor"
       strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={style}>
    {d ? <path d={d} /> : children}
  </svg>
);

const Icons = {
  Chevron: (p) => <Icon {...p} d="M9 6l6 6-6 6" />,
  ChevronDown: (p) => <Icon {...p} d="M6 9l6 6 6-6" />,
  Search: (p) => <Icon {...p}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></Icon>,
  Video: (p) => <Icon {...p}><rect x="2.5" y="6" width="13" height="12" rx="2" /><path d="M15.5 10l6-3v10l-6-3" /></Icon>,
  Mic: (p) => <Icon {...p}><rect x="9" y="2.5" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18.5V22" /></Icon>,
  Transcript: (p) => <Icon {...p}><rect x="4" y="3" width="16" height="18" rx="2" /><path d="M8 8h8M8 12h8M8 16h5" /></Icon>,
  Clock: (p) => <Icon {...p}><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 1.8" /></Icon>,
  Calendar: (p) => <Icon {...p}><rect x="3.5" y="5" width="17" height="16" rx="2" /><path d="M3.5 9.5h17M8 3v4M16 3v4" /></Icon>,
  Users: (p) => <Icon {...p}><circle cx="9" cy="8" r="3.2" /><path d="M3.5 20a5.5 5.5 0 0 1 11 0M16 6.2a3.2 3.2 0 0 1 0 6M17.5 20a5.5 5.5 0 0 0-3-4.9" /></Icon>,
  Sparkle: (p) => <Icon {...p} fill="currentColor" sw={0}><path d="M12 2.5l1.7 5.3a4 4 0 0 0 2.5 2.5L21.5 12l-5.3 1.7a4 4 0 0 0-2.5 2.5L12 21.5l-1.7-5.3a4 4 0 0 0-2.5-2.5L2.5 12l5.3-1.7a4 4 0 0 0 2.5-2.5z" /></Icon>,
  Check: (p) => <Icon {...p} d="M4.5 12.5l5 5 10-11" sw={2} />,
  CheckCircle: (p) => <Icon {...p}><circle cx="12" cy="12" r="9" /><path d="M8 12.2l2.6 2.6L16 9" /></Icon>,
  Circle: (p) => <Icon {...p}><circle cx="12" cy="12" r="8.5" /></Icon>,
  Send: (p) => <Icon {...p}><path d="M4 12l16-7-7 16-2.5-6.5L4 12z" /></Icon>,
  Link: (p) => <Icon {...p}><path d="M9 15l6-6M10.5 6.5l1.8-1.8a4 4 0 0 1 5.7 5.7l-1.8 1.8M13.5 17.5l-1.8 1.8a4 4 0 0 1-5.7-5.7l1.8-1.8" /></Icon>,
  Play: (p) => <Icon {...p} fill="currentColor" sw={0}><path d="M7 4.5l13 7.5-13 7.5z" /></Icon>,
  Filter: (p) => <Icon {...p} d="M3 5h18l-7 8v6l-4-2v-4z" />,
  Expand: (p) => <Icon {...p}><path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M21 16v3a2 2 0 0 1-2 2h-3M3 16v3a2 2 0 0 0 2 2h3" /></Icon>,
  Collapse: (p) => <Icon {...p}><path d="M3 8h3a2 2 0 0 0 2-2V3M21 8h-3a2 2 0 0 1-2-2V3M16 21v-3a2 2 0 0 1 2-2h3M8 21v-3a2 2 0 0 0-2-2H3" /></Icon>,
  Plus: (p) => <Icon {...p} d="M12 5v14M5 12h14" />,
  Close: (p) => <Icon {...p} d="M6 6l12 12M18 6L6 18" />,
  Edit: (p) => <Icon {...p}><path d="M4 20h4l11-11a2.1 2.1 0 0 0-3-3L5 17z" /><path d="M14 6l3 3" /></Icon>,
  Split: (p) => <Icon {...p}><path d="M12 4v16M6 8l-2 4 2 4M18 8l2 4-2 4" /></Icon>,
  Merge: (p) => <Icon {...p}><path d="M7 4v6a4 4 0 0 0 4 4h6M7 20v-6M17 8l3 3-3 3" /></Icon>,
  Wand: (p) => <Icon {...p}><path d="M15 4V2M15 10v-2M11 6H9M21 6h-2M17.6 8.6l-1.4-1.4M4 20l9.5-9.5M16.4 7.4l1.4-1.4" /></Icon>,
  List: (p) => <Icon {...p} d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01" />,
  Grid: (p) => <Icon {...p}><rect x="3.5" y="3.5" width="7" height="7" rx="1.5" /><rect x="13.5" y="3.5" width="7" height="7" rx="1.5" /><rect x="3.5" y="13.5" width="7" height="7" rx="1.5" /><rect x="13.5" y="13.5" width="7" height="7" rx="1.5" /></Icon>,
  Arrow: (p) => <Icon {...p} d="M5 12h14M13 6l6 6-6 6" />,
  Logout: (p) => <Icon {...p}><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 12h10M16 8l4 4-4 4" /></Icon>,
  Shield: (p) => <Icon {...p}><path d="M12 3l7 3v5c0 4.5-3 7.6-7 9-4-1.4-7-4.5-7-9V6z" /><path d="M9 12l2 2 4-4" /></Icon>,
  Flag: (p) => <Icon {...p}><path d="M5 21V4M5 4h11l-2 4 2 4H5" /></Icon>,
  Layers: (p) => <Icon {...p}><path d="M12 3l9 5-9 5-9-5z" /><path d="M3 13l9 5 9-5" /></Icon>,
  Dots: (p) => <Icon {...p} fill="currentColor" sw={0}><circle cx="5" cy="12" r="1.6" /><circle cx="12" cy="12" r="1.6" /><circle cx="19" cy="12" r="1.6" /></Icon>,
};

// Microsoft 4-square logo
const MicrosoftLogo = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 21 21" aria-hidden="true">
    <rect x="0" y="0" width="9.5" height="9.5" fill="#F25022" />
    <rect x="11.5" y="0" width="9.5" height="9.5" fill="#7FBA00" />
    <rect x="0" y="11.5" width="9.5" height="9.5" fill="#00A4EF" />
    <rect x="11.5" y="11.5" width="9.5" height="9.5" fill="#FFB900" />
  </svg>
);

// Azure DevOps infinity mark (placeholder brand mark, azure blue)
const AzureDevOpsLogo = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <path d="M7 8.5a3.5 3.5 0 1 0 0 7c2 0 3-1.6 4-3.5 1-1.9 2-3.5 4-3.5a3.5 3.5 0 1 1 0 7c-2 0-3-1.6-4-3.5-1-1.9-2-3.5-4-3.5z"
          stroke="#0078D4" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// Teams hexagon-ish mark (placeholder)
const TeamsLogo = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <circle cx="16.5" cy="6" r="2.4" fill="#5b5fc7" />
    <rect x="3" y="6.5" width="11" height="11" rx="2.4" fill="#5b5fc7" />
    <path d="M6.2 10.2h5.6M9 10.2V14" stroke="#fff" strokeWidth="1.4" strokeLinecap="round" />
    <path d="M14 9.2h6.4c.6 0 1 .4 1 1v4.2a3.2 3.2 0 0 1-3.2 3.2H16" fill="#7a7ed6" />
  </svg>
);

const AgentMark = ({ size = 22 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <defs>
      <linearGradient id="agm" x1="0" y1="0" x2="24" y2="24">
        <stop offset="0" stopColor="#13b257" />
        <stop offset="0.5" stopColor="#0a8a3f" />
        <stop offset="1" stopColor="#0a6e4c" />
      </linearGradient>
    </defs>
    <path d="M12 2l2.1 6.4a4 4 0 0 0 2.5 2.5L23 13l-6.4 2.1a4 4 0 0 0-2.5 2.5L12 24l-2.1-6.4a4 4 0 0 0-2.5-2.5L1 13l6.4-2.1a4 4 0 0 0 2.5-2.5z" fill="url(#agm)" />
  </svg>
);

Object.assign(window, { Icon, Icons, MicrosoftLogo, AzureDevOpsLogo, TeamsLogo, AgentMark });
