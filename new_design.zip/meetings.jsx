/* Agent Genesis — Meeting records browser + selection */
function MeetingsScreen({ onGenerate, onSignOut }) {
  const all = window.AG.meetings;
  const [selected, setSelected] = React.useState(() => new Set());
  const [query, setQuery] = React.useState("");
  const [view, setView] = React.useState("list");
  const [onlyVideo, setOnlyVideo] = React.useState(false);

  const toggle = (id) => {
    setSelected((prev) => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  const filtered = all.filter((m) => {
    if (onlyVideo && !m.hasVideo) return false;
    if (!query) return true;
    const q = query.toLowerCase();
    return m.title.toLowerCase().includes(q) || m.channel.toLowerCase().includes(q) || m.organizer.toLowerCase().includes(q);
  });

  const selectedMeetings = all.filter((m) => selected.has(m.id));

  return (
    <div className="screen meetings">
      <AppHeader onSignOut={onSignOut} crumb="Meeting records" />

      <div className="meetings__body">
        <div className="meetings__intro">
          <div>
            <h1>Select meetings to analyze</h1>
            <p>Agent Genesis reads the video and transcript, then drafts a backlog you can review and refine.</p>
          </div>
        </div>

        <div className="meetings__toolbar">
          <div className="ag-searchbox">
            <Icons.Search size={16} />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search meetings, channels, organizers…" />
          </div>
          <button className={`ag-chiptoggle ${onlyVideo ? "is-on" : ""}`} onClick={() => setOnlyVideo((v) => !v)}>
            <Icons.Video size={15} /> Has video
          </button>
          <div className="meetings__spacer" />
          <Segmented value={view} onChange={setView} options={[
            { value: "list", icon: <Icons.List size={16} /> },
            { value: "grid", icon: <Icons.Grid size={16} /> },
          ]} />
        </div>

        <div className={`meetings__list ${view === "grid" ? "is-grid" : ""}`}>
          {filtered.map((m) => (
            <MeetingRow key={m.id} m={m} view={view} checked={selected.has(m.id)} onToggle={() => toggle(m.id)} />
          ))}
          {filtered.length === 0 && <div className="meetings__empty">No meetings match your filters.</div>}
        </div>
      </div>

      {/* Selection action bar */}
      <div className={`selbar ${selected.size ? "is-up" : ""}`}>
        <div className="selbar__inner">
          <div className="selbar__count">
            <span className="selbar__num">{selected.size}</span>
            <span>{selected.size === 1 ? "meeting" : "meetings"} selected</span>
            {selectedMeetings.length > 0 && (
              <span className="selbar__names">{selectedMeetings.map((m) => m.title).join(" · ")}</span>
            )}
          </div>
          <div className="selbar__actions">
            <Btn variant="ghost" onClick={() => setSelected(new Set())}>Clear</Btn>
            <Btn variant="primary" icon={<AgentMark size={16} />} iconRight={<Icons.Arrow size={16} />}
                 onClick={() => onGenerate(selectedMeetings)}>
              Generate user stories
            </Btn>
          </div>
        </div>
      </div>
    </div>
  );
}

function MeetingRow({ m, checked, onToggle, view }) {
  return (
    <button className={`mrow ${checked ? "is-checked" : ""} ${view === "grid" ? "mrow--grid" : ""}`} onClick={onToggle}>
      <div className="mrow__check"><span className="mrow__box">{checked && <Icons.Check size={13} sw={2.6} />}</span></div>
      <FrameThumb ts={m.duration} tint={m.tint} w={view === "grid" ? 999 : 128} h={view === "grid" ? 150 : 74} />
      <div className="mrow__main">
        <div className="mrow__top">
          <TeamsLogo size={15} />
          <span className="mrow__channel">{m.channel}</span>
        </div>
        <div className="mrow__title">{m.title}</div>
        <div className="mrow__meta">
          <span><Icons.Calendar size={14} /> {m.date}</span>
          <span><Icons.Clock size={14} /> {m.duration}</span>
          <span className="mrow__org">Organized by {m.organizer}</span>
        </div>
        <div className="mrow__foot">
          <AvatarStack names={m.attendees} size={24} />
          <div className="mrow__badges">
            {m.hasVideo && <span className="mrow__badge"><Icons.Video size={13} /> Video</span>}
            {m.hasTranscript && <span className="mrow__badge"><Icons.Transcript size={13} /> Transcript · {(m.transcriptWords/1000).toFixed(1)}k words</span>}
          </div>
        </div>
      </div>
    </button>
  );
}

window.MeetingsScreen = MeetingsScreen;
