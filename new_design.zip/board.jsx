/* Agent Genesis — Board view: Epic swimlane columns (alternative to the Nested view) */

function boardPoints(node) {
  let v = node.points || 0;
  (node.children || []).forEach((c) => { v += boardPoints(c); });
  return v;
}

function BoardView({ data, focusedId, onFocus, onApprove, onJump, onOpenDetail }) {
  return (
    <div className="board">
      {data.map((epic) => {
        const sub = window.countStatus(epic.children || []);
        return (
          <div key={epic.id} className={`bcol ${epic.status === "approved" ? "is-approved" : ""}`}>
            <div className={`bcol__head ${focusedId === epic.id ? "is-focused" : ""}`}
                 onClick={() => onOpenDetail(epic)}>
              <div className="bcol__headtop">
                <TypeGlyph type="epic" size={24} />
                <div className="bcol__headmeta">
                  <span className="bcol__id">{epic.id}</span>
                  {epic.priority && <PriorityTag priority={epic.priority} />}
                </div>
                <ApproveBox status={epic.status} onClick={(e) => { e.stopPropagation(); onApprove(epic.id); }} />
              </div>
              <div className="bcol__title">{epic.title}</div>
              <div className="bcol__stats">
                <span><b>{(epic.children || []).length}</b> features</span>
                <span className="bcol__dot" />
                <span><b>{boardPoints(epic)}</b> pts</span>
                <span className="bcol__dot" />
                <span className="bcol__prog">{sub.approved}/{sub.total} approved</span>
              </div>
              <div className="bcol__bar"><div className="bcol__barfill" style={{ width: (sub.total ? sub.approved / sub.total * 100 : 0) + "%" }} /></div>
            </div>

            <div className="bcol__body">
              {(epic.children || []).map((feat) => (
                <div key={feat.id} className="bgroup">
                  <div className={`bgroup__head ${focusedId === feat.id ? "is-focused" : ""}`}
                       onClick={() => onOpenDetail(feat)}>
                    <TypePill type="feature" size="sm" />
                    <span className="bgroup__title">{feat.title}</span>
                    {feat.priority && <PriorityTag priority={feat.priority} />}
                    <ApproveBox status={feat.status} onClick={(e) => { e.stopPropagation(); onApprove(feat.id); }} />
                  </div>

                  <div className="bgroup__cards">
                    {(feat.children || []).map((story) => (
                      <BoardStory key={story.id} story={story} focusedId={focusedId}
                                  onApprove={onApprove} onJump={onJump} onOpenDetail={onOpenDetail} />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function BoardStory({ story, focusedId, onApprove, onJump, onOpenDetail }) {
  const tasks = story.children || [];
  return (
    <div className={`bcard ${story.status === "approved" ? "is-approved" : ""} ${focusedId === story.id ? "is-focused" : ""} ${story.status === "suggested" ? "is-suggested" : ""}`}>
      <div className="bcard__main" onClick={() => onOpenDetail(story)}>
        <div className="bcard__top">
          <TypePill type="story" size="sm" />
          <span className="bcard__id">{story.id}</span>
          <ApproveBox status={story.status} onClick={(e) => { e.stopPropagation(); onApprove(story.id); }} />
        </div>
        <div className="bcard__title">{story.title}</div>
        <div className="bcard__meta">
          {story.priority && <PriorityTag priority={story.priority} />}
          {story.points != null && <Points value={story.points} />}
          {story.ac && story.ac.length > 0 && <span className="bcard__ac"><Icons.Check size={12} sw={2.4} /> {story.ac.length} AC</span>}
          <SourceChip source={story.source} onJump={(e) => { e.stopPropagation(); onJump(story); }} />
        </div>
      </div>

      {tasks.length > 0 && (
        <div className="bcard__tasks">
          {tasks.map((task) => (
            <button key={task.id} className={`btask ${task.status === "approved" ? "is-approved" : ""}`}
                    onClick={() => onOpenDetail(task)}>
              <span className="btask__check" onClick={(e) => { e.stopPropagation(); onApprove(task.id); }}>
                {task.status === "approved" ? <Icons.Check size={11} sw={2.8} /> : <span className="btask__dot" />}
              </span>
              <span className="btask__title">{task.title}</span>
              {task.points != null && <span className="btask__pts">{task.points}</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// Detail drawer (used by the Board view when a card is opened)
function NodeDrawer({ node, onClose, onApprove, onJump }) {
  if (!node) return null;
  const approved = node.status === "approved";
  return (
    <div className="modal" onClick={onClose}>
      <div className="ndrawer" onClick={(e) => e.stopPropagation()}>
        <div className="ndrawer__head">
          <TypeGlyph type={node.type} size={30} />
          <div className="ndrawer__headinfo">
            <div className="ndrawer__headtop">
              <TypePill type={node.type} size="sm" />
              <span className="ndrawer__id">{node.id}</span>
              {node.priority && <PriorityTag priority={node.priority} />}
              {node.points != null && <Points value={node.points} />}
            </div>
            <h2 className="ndrawer__title">{node.title}</h2>
          </div>
          <button className="modal__close ndrawer__close" onClick={onClose}><Icons.Close size={18} /></button>
        </div>
        <div className="ndrawer__body">
          <NodeDetail node={node} onJump={onJump} />
        </div>
        <div className="ndrawer__foot">
          <span className="ndrawer__footstatus">
            {approved ? <React.Fragment><Icons.CheckCircle size={15} /> Approved</React.Fragment> : "Pending review"}
          </span>
          <Btn variant={approved ? "default" : "primary"} icon={approved ? <Icons.Close size={15} /> : <Icons.Check size={15} sw={2.4} />}
               onClick={() => onApprove(node.id)}>
            {approved ? "Unapprove" : "Approve item"}
          </Btn>
        </div>
      </div>
    </div>
  );
}

window.BoardView = BoardView;
window.NodeDrawer = NodeDrawer;
